import { test, expect } from '../fixtures/testFixture';
import { CheckoutScenarios } from '../scenarios/CheckoutScenarios';
import { GUEST_ADDRESS, TEST_CARD, DEMO_USER } from '../config/testData';

/**
 * Reference E2E against SauceDemo. Demonstrates the full stack — scenario layer
 * -> base page bodies -> registry-resolved selectors -> demo payment strategy —
 * passing green. Run with:  npm run test:saucedemo
 */
test.describe('Demo brand — full guest checkout (green)', () => {
  test('TC001 - guest can browse, add to cart, and place an order', async ({ page, brand }) => {
    test.skip(brand.platform !== 'demo', 'Demo-only spec; live brands use the live spec.');

    // SauceDemo requires a login before the storefront is visible.
    await page.goto('/');
    await page.locator('#user-name').fill(DEMO_USER.username);
    await page.locator('#password').fill(DEMO_USER.password);
    await page.locator('#login-button').click();
    await expect(page.locator('.inventory_list')).toBeVisible();

    const scenarios = new CheckoutScenarios(page, brand);

    const productName = await scenarios.browseAndAddToCart();
    expect(productName.length).toBeGreaterThan(0);

    const orderConfirmation = await scenarios.guestCheckout(GUEST_ADDRESS, TEST_CARD);
    expect(orderConfirmation.toLowerCase()).toContain('thank you');
  });
});
