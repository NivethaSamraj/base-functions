import { test, expect } from '../fixtures/testFixture';
import { CheckoutScenarios } from '../scenarios/CheckoutScenarios';
import { GUEST_ADDRESS, TEST_CARD } from '../config/testData';

/**
 * Live-brand specs. The SAME scenario layer as the demo — only the brand
 * (BRAND=anntaylor) and the resolved selectors differ. Run with:
 *   npm run test:anntaylor
 *
 * Expectation, stated honestly:
 *   - The discovery/cart scenario should pass once the Ann Taylor override
 *     selectors are filled from real outerHTML.
 *   - The full checkout will reach the payment step and then fail fast with the
 *     gateway's reason until a valid Aurus sandbox card replaces 4111...
 *     That is correct behaviour, not a framework bug.
 */
test.describe('Ann Taylor — live', () => {
  test('TC101 - browse PLP, open PDP, add to cart, reach cart', async ({ page, brand }) => {
    test.skip(brand.id !== 'anntaylor', 'Ann Taylor only.');

    await page.goto('/'); // TODO: navigate to a category/PLP URL
    // TODO: the home->PLP nav step depends on Ann Taylor's nav; add it here.

    const scenarios = new CheckoutScenarios(page, brand);
    const productName = await scenarios.browseAndAddToCart();
    expect(productName.length).toBeGreaterThan(0);
  });

  test('TC102 - guest checkout reaches payment (stops at card until sandbox PAN)', async ({ page, brand }) => {
    test.skip(brand.id !== 'anntaylor', 'Ann Taylor only.');
    test.fixme(true, 'Enable once shipping selectors verified AND a valid Aurus sandbox card is set.');

    await page.goto('/');
    const scenarios = new CheckoutScenarios(page, brand);
    await scenarios.browseAndAddToCart();
    const conf = await scenarios.guestCheckout(GUEST_ADDRESS, TEST_CARD);
    expect(conf.length).toBeGreaterThan(0);
  });
});
