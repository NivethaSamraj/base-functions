import { Page } from '@playwright/test';
import { BaseCheckoutPage } from '../base/BaseCheckoutPage';
import { PaymentStrategy } from '../payments/PaymentStrategy';

/**
 * LaneBryant checkout page object  (brand id: 'lanebryant', platform: SFCC).
 *
 * Inherits every Shared/Override method body from BaseCheckoutPage. LaneBryant's
 * selector differences live in locators/brands/lanebryant/, and its payment is the
 * shared SFCC-Aurus strategy. Override a method below ONLY if LaneBryant's checkout
 * FLOW diverges (an extra step/modal) — not for selectors or payment.
 */
export class LaneBryantCheckoutPage extends BaseCheckoutPage {
  constructor(page: Page, payment: PaymentStrategy) {
    super(page, 'lanebryant', payment);
  }

  // No flow divergence known for LaneBryant yet — inherits base.
  // Example (enable only if real):
  // async continueShipping(): Promise<void> {
  //   await super.continueShipping();
  //   // LaneBryant-only extra step here
  // }
}
