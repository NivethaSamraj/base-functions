import { Page } from '@playwright/test';
import { BaseCheckoutPage } from '../base/BaseCheckoutPage';
import { PaymentStrategy } from '../payments/PaymentStrategy';

/**
 * Talbots checkout page object  (brand id: 'talbots', platform: SFCC).
 *
 * Inherits every Shared/Override method body from BaseCheckoutPage. Talbots's
 * selector differences live in locators/brands/talbots/, and its payment is the
 * shared SFCC-Aurus strategy. Override a method below ONLY if Talbots's checkout
 * FLOW diverges (an extra step/modal) — not for selectors or payment.
 */
export class TalbotsCheckoutPage extends BaseCheckoutPage {
  constructor(page: Page, payment: PaymentStrategy) {
    super(page, 'talbots', payment);
  }

  // No flow divergence known for Talbots yet — inherits base.
  // Example (enable only if real):
  // async continueShipping(): Promise<void> {
  //   await super.continueShipping();
  //   // Talbots-only extra step here
  // }
}
