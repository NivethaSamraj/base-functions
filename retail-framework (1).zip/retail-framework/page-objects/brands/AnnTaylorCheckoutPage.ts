import { Page } from '@playwright/test';
import { BaseCheckoutPage } from '../base/BaseCheckoutPage';
import { PaymentStrategy } from '../payments/PaymentStrategy';

/**
 * AnnTaylor checkout page object  (brand id: 'anntaylor', platform: SFCC).
 *
 * Inherits every Shared/Override method body from BaseCheckoutPage. AnnTaylor's
 * selector differences live in locators/brands/anntaylor/, and its payment is the
 * shared SFCC-Aurus strategy. Override a method below ONLY if AnnTaylor's checkout
 * FLOW diverges (an extra step/modal) — not for selectors or payment.
 */
export class AnnTaylorCheckoutPage extends BaseCheckoutPage {
  constructor(page: Page, payment: PaymentStrategy) {
    super(page, 'anntaylor', payment);
  }

  // No flow divergence known for AnnTaylor yet — inherits base.
  // Example (enable only if real):
  // async continueShipping(): Promise<void> {
  //   await super.continueShipping();
  //   // AnnTaylor-only extra step here
  // }
}
