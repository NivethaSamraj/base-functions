import { Page } from '@playwright/test';
import { CheckoutLocators } from '../../locators/registry/locatorTypes';

export interface CardDetails {
  nameOnCard: string;
  cardNumber: string;
  expMonth: string;
  expYear: string;
  cvv: string;
}

export type PaymentOutcome = 'placeorder' | 'error' | 'timeout';

/**
 * A PaymentStrategy encapsulates the ONE part of checkout that genuinely
 * differs by platform (the "Brand-specific" bucket). The shared checkout flow
 * delegates to it instead of branching internally, so adding a new payment
 * platform never touches the shared shipping/cart/confirmation code.
 */
export interface PaymentStrategy {
  /**
   * Enter payment details and advance to the Place Order step.
   * Returns a discriminated outcome so callers can fail fast with a reason.
   */
  pay(
    page: Page,
    locators: CheckoutLocators,
    card: CardDetails
  ): Promise<{ outcome: PaymentOutcome; message?: string }>;
}
