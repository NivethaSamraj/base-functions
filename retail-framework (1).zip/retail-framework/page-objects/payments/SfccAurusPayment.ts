import { Page } from '@playwright/test';
import { CheckoutLocators } from '../../locators/registry/locatorTypes';
import { CardDetails, PaymentOutcome, PaymentStrategy } from './PaymentStrategy';

/**
 * SFCC + Aurus credit-card payment.
 *
 * This is the production-grade version of the checkout fix we built earlier:
 *  - commits the card number and verifies it stuck (catches iframe remount)
 *  - races the Place Order signal against a billing error so a declined card
 *    fails in ~2s with the gateway message instead of a 30s timeout
 *
 * If the card fields are inside an Aurus IFRAME, switch `root` below to
 * page.frameLocator('<iframe selector>') and resolve fields from it.
 */
export class SfccAurusPayment implements PaymentStrategy {
  async pay(
    page: Page,
    L: CheckoutLocators,
    card: CardDetails
  ): Promise<{ outcome: PaymentOutcome; message?: string }> {
    // Select credit card
    await L.radCreditCard(page).click({ force: true }).catch(() => {});

    // Fill card fields. If iframed, replace page-rooted locators with a frame.
    const name = L.inpCardName(page);
    await name.waitFor({ state: 'visible', timeout: 30000 });
    await name.click();
    await name.pressSequentially(card.nameOnCard, { delay: 50 });

    const num = L.inpCardNumber(page);
    await num.click();
    await num.pressSequentially(card.cardNumber, { delay: 50 });
    await num.blur();

    await this.selectByValue(L.drpCardExpMonth(page), card.expMonth);
    await this.selectByValue(L.drpCardExpYear(page), card.expYear);

    const cvv = L.inpCardCvv(page);
    await cvv.click();
    await cvv.pressSequentially(card.cvv, { delay: 50 });
    await cvv.blur();

    // Verify the card number committed (Aurus remount can silently wipe it).
    const committed = (await num.inputValue().catch(() => '')).replace(/\s/g, '');
    if (!committed || committed.length < 12) {
      return {
        outcome: 'error',
        message: `Card number did not commit (got "${committed}"). Field likely inside an iframe — use frameLocator.`,
      };
    }

    // Advance billing -> place order, racing success vs. validation error.
    const cont = L.btnContinueBilling(page);
    await cont.waitFor({ state: 'visible', timeout: 30000 });
    await page.locator('body').click({ position: { x: 0, y: 0 } }).catch(() => {});
    await cont.click();

    const placeOrder = L.placeOrderReady(page);
    const billingError = L.billingError(page);

    const outcome = await Promise.race([
      placeOrder.waitFor({ state: 'visible', timeout: 30000 }).then(() => 'placeorder' as const),
      billingError.waitFor({ state: 'visible', timeout: 30000 }).then(() => 'error' as const),
    ]).catch(() => 'timeout' as const);

    if (outcome === 'error') {
      const msg = (await billingError.textContent().catch(() => ''))?.trim();
      return { outcome, message: `Billing rejected: "${msg}"` };
    }
    if (outcome === 'timeout') {
      return {
        outcome,
        message: 'Place Order never appeared — card may be declined on this environment (use a valid Aurus sandbox PAN).',
      };
    }
    return { outcome: 'placeorder' };
  }

  private async selectByValue(locator: ReturnType<CheckoutLocators['drpCardExpMonth']>, value: string) {
    await locator.selectOption(value).catch(() => {});
  }
}
