import { Page } from '@playwright/test';
import { CheckoutLocators } from '../../locators/registry/locatorTypes';
import { CardDetails, PaymentOutcome, PaymentStrategy } from './PaymentStrategy';

/**
 * Demo payment for storefronts with no real payment step (e.g. SauceDemo).
 * It simply clicks the finish/continue button and confirms the order page.
 * Lets the reference brand run fully green end-to-end.
 */
export class DemoNoOpPayment implements PaymentStrategy {
  async pay(
    page: Page,
    L: CheckoutLocators,
    _card: CardDetails
  ): Promise<{ outcome: PaymentOutcome; message?: string }> {
    const finish = L.btnContinueBilling(page);
    await finish.waitFor({ state: 'visible', timeout: 15000 });
    await finish.click();
    return { outcome: 'placeorder' };
  }
}
