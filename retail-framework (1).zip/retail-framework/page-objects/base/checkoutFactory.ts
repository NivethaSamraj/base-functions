import { Page } from '@playwright/test';
import { BaseCheckoutPage } from './BaseCheckoutPage';
import { AnnTaylorCheckoutPage } from '../brands/AnnTaylorCheckoutPage';
import { TalbotsCheckoutPage } from '../brands/TalbotsCheckoutPage';
import { LaneBryantCheckoutPage } from '../brands/LaneBryantCheckoutPage';
import { BrandConfig } from '../../config/brands';
import { PaymentStrategy } from '../payments/PaymentStrategy';
import { SfccAurusPayment } from '../payments/SfccAurusPayment';
import { DemoNoOpPayment } from '../payments/DemoNoOpPayment';

/** Payment strategy by platform. The only place platform -> payment maps. */
function paymentFor(brand: BrandConfig): PaymentStrategy {
  switch (brand.platform) {
    case 'sfcc':
      return new SfccAurusPayment();
    case 'demo':
      return new DemoNoOpPayment();
    case 'other':
      return new DemoNoOpPayment(); // placeholder until an other-platform strategy is wired
    default:
      return new DemoNoOpPayment();
  }
}

/**
 * Brand id -> named page object. Each brand is identifiable here by name.
 *
 * The per-brand classes currently inherit the base flow (their differences are
 * selectors in locators/brands/<id>/ and the shared SFCC payment strategy).
 * They exist as named seams so that the day a brand's FLOW diverges, you add the
 * override to that brand's own file — no hunting, no shared-class edits.
 */
export function createCheckoutPage(page: Page, brand: BrandConfig): BaseCheckoutPage {
  const payment = paymentFor(brand);

  switch (brand.id) {
    case 'anntaylor':
      return new AnnTaylorCheckoutPage(page, payment);
    case 'talbots':
      return new TalbotsCheckoutPage(page, payment);
    case 'lanebryant':
      return new LaneBryantCheckoutPage(page, payment);
    case 'saucedemo':
    default:
      return new BaseCheckoutPage(page, brand.id, payment);
  }
}
