import { Page, Locator } from '@playwright/test';

/**
 * A LocatorFactory is a function that, given the current Page, returns a
 * Playwright Locator. We store factories (not Locators) because locators are
 * lazy — they must be re-resolved against the live DOM at the moment of use.
 */
export type LocatorFactory = (page: Page) => Locator;

/**
 * The COMPLETE set of locator keys the framework knows about.
 *
 * This interface is the contract. The base locator file must implement ALL of
 * these. Every brand override file is typed as Partial<CheckoutLocators>, so:
 *   - a misspelled key  -> compile error (excess property check)
 *   - a wrong signature -> compile error
 * That converts the classic "silent shadow / silent fallback" bug (which bites
 * hard at 8 brands) into a build-time failure.
 */
export interface CheckoutLocators {
  // --- Discovery / header ---
  headerSearchInput: LocatorFactory;
  headerSearchSubmit: LocatorFactory;

  // --- PLP ---
  plpProductTile: LocatorFactory;
  plpAddToCartButton: LocatorFactory;

  // --- PDP ---
  pdpProductName: LocatorFactory;
  pdpSizeOption: LocatorFactory;
  pdpAddToCartButton: LocatorFactory;
  pdpGoToCartLink: LocatorFactory;

  // --- Cart ---
  cartProductName: LocatorFactory;
  cartProductPrice: LocatorFactory;
  cartCheckoutButton: LocatorFactory;

  // --- Checkout: identification ---
  checkoutAsGuestButton: LocatorFactory;

  // --- Checkout: shipping ---
  inpFirstName: LocatorFactory;
  inpLastName: LocatorFactory;
  inpEmail: LocatorFactory;
  inpAddress1: LocatorFactory;
  inpZipCode: LocatorFactory;
  inpCity: LocatorFactory;
  drpState: LocatorFactory;
  inpPhone: LocatorFactory;
  btnContinueShipping: LocatorFactory;

  // success / error signals for the shipping->billing transition
  paymentSectionReady: LocatorFactory;
  shippingError: LocatorFactory;

  // --- Checkout: payment (used by payment strategies) ---
  radCreditCard: LocatorFactory;
  inpCardNumber: LocatorFactory;
  inpCardName: LocatorFactory;
  drpCardExpMonth: LocatorFactory;
  drpCardExpYear: LocatorFactory;
  inpCardCvv: LocatorFactory;
  btnContinueBilling: LocatorFactory;

  // success / error signals for the billing->placeorder transition
  placeOrderReady: LocatorFactory;
  billingError: LocatorFactory;

  // --- Order confirmation ---
  btnPlaceOrder: LocatorFactory;
  orderConfirmationId: LocatorFactory;
}

/** Brand override files implement only the keys that differ from base. */
export type BrandLocatorOverride = Partial<CheckoutLocators>;
