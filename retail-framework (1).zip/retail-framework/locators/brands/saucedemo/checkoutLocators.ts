import { BrandLocatorOverride } from '../../registry/locatorTypes';

/**
 * SauceDemo brand override.
 *
 * The base locators ARE the SauceDemo selectors, so this brand overrides
 * nothing — every key is SHARED. This is the cleanest illustration of the
 * "Shared" bucket: an empty override file means the brand uses base as-is.
 */
export const saucedemoLocators: BrandLocatorOverride = {
  // (intentionally empty — all keys inherited from base)
};
