import { Page } from '@playwright/test';
import { BrandLocatorOverride } from '../../registry/locatorTypes';

/**
 * talbots brand override  (SFCC platform).
 *
 * ⚠️  PLACEHOLDER SELECTORS — these are structurally correct but NOT verified
 *     against the live talbots DOM. Replace each one using the real
 *     outerHTML you inspect on talbots.com.
 *
 * Only the OVERRIDE keys need to live here — anything talbots shares with
 * base (rare across platforms, common within SFCC) can be deleted from this
 * file to fall back to base.
 *
 * The method BODIES (enterShippingAddressDetails, clickContinueShipping, etc.)
 * are NOT here — they live once in the SFCC base page object. This file is
 * pure data: which selector each key points at for talbots.
 */
export const talbotsLocators: BrandLocatorOverride = {
  // --- Discovery / header ---
  headerSearchInput: (page: Page) => page.locator('input#searchField, input[name="q"]'), // TODO verify
  headerSearchSubmit: (page: Page) => page.locator('button[type="submit"][name="search"]'), // TODO verify

  // --- PLP ---
  plpProductTile: (page: Page) => page.locator('.product-tile a.thumb-link, .product-tile a.pdp-link'), // TODO
  plpAddToCartButton: (page: Page) => page.locator('.product-tile button.add-to-cart'), // TODO

  // --- PDP ---
  pdpProductName: (page: Page) => page.locator('h1.product-name, .product-name'), // TODO
  pdpSizeOption: (page: Page) => page.locator('.size-attribute button:not([disabled]), .swatch-size .selectable'), // TODO
  pdpAddToCartButton: (page: Page) => page.locator('button.add-to-cart'), // TODO
  pdpGoToCartLink: (page: Page) => page.locator('.minicart-link, a.minicart'), // TODO

  // --- Cart ---
  cartProductName: (page: Page) => page.locator('.line-item-name, .product-line-item .item-name'), // TODO
  cartProductPrice: (page: Page) => page.locator('.line-item-total-price .value, .pricing'), // TODO
  cartCheckoutButton: (page: Page) => page.locator('.checkout-btn, button.checkout'), // TODO

  // --- Checkout: identification ---
  checkoutAsGuestButton: (page: Page) => page.locator('.checkout-as-guest, button[value="guest"]'), // TODO

  // --- Checkout: shipping (SFCC dwfrm_shipping conventions) ---
  inpFirstName: (page: Page) => page.locator('input[name*="shippingFirstName"], #shippingFirstNamedefault'), // TODO
  inpLastName: (page: Page) => page.locator('input[name*="shippingLastName"], #shippingLastNamedefault'), // TODO
  inpEmail: (page: Page) => page.locator('input[name*="email"], #email-guest'), // TODO
  inpAddress1: (page: Page) => page.locator('input[name*="address1"], #shippingAddressOnedefault'), // TODO
  inpZipCode: (page: Page) => page.locator('input[name*="postalCode"], #shippingZipCodedefault'), // TODO
  inpCity: (page: Page) => page.locator('input[name*="city"], #shippingAddressCitydefault'), // TODO
  drpState: (page: Page) => page.locator('select[name*="stateCode"], #shippingStatedefault'), // TODO
  inpPhone: (page: Page) => page.locator('input[name*="phone"], #shippingPhoneNumberdefault'), // TODO
  btnContinueShipping: (page: Page) => page.locator('button.submit-shipping, button[value="submit-shipping"]'), // TODO

  paymentSectionReady: (page: Page) =>
    page.locator('#payment-methods-area, form#dwfrm_billing, #is-CREDIT_CARD').first(), // TODO
  shippingError: (page: Page) =>
    page.locator('.shipping-error .alert-danger, .invalid-feedback:visible').first(), // TODO

  // --- Checkout: payment ---
  radCreditCard: (page: Page) => page.locator('#is-CREDIT_CARD, input[value="CREDIT_CARD"]'), // TODO
  inpCardNumber: (page: Page) => page.locator('#cardNumber, input[name*="cardNumber"]'), // TODO — note iframe?
  inpCardName: (page: Page) => page.locator('#cardOwner, input[name*="cardOwner"]'), // TODO
  drpCardExpMonth: (page: Page) => page.locator('#expirationMonth, select[name*="month"]'), // TODO
  drpCardExpYear: (page: Page) => page.locator('#expirationYear, select[name*="year"]'), // TODO
  inpCardCvv: (page: Page) => page.locator('#securityCode, input[name*="securityCode"]'), // TODO
  btnContinueBilling: (page: Page) => page.locator('button.submit-payment, button[value="submit-payment"]'), // TODO

  placeOrderReady: (page: Page) =>
    page.locator('button.place-order, button[name="submit"][value*="place-order"]').first(), // TODO
  billingError: (page: Page) =>
    page.locator('#dwfrm_billing .invalid-feedback:visible, .alert-danger:visible').first(), // TODO

  // --- Order confirmation ---
  btnPlaceOrder: (page: Page) => page.locator('button.place-order'), // TODO
  orderConfirmationId: (page: Page) => page.locator('.order-number, .confirmation-order-number'), // TODO
};
