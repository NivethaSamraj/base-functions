import { Page } from '@playwright/test';
import { CheckoutLocators } from '../registry/locatorTypes';

/**
 * BASE locators — the default selector for every key.
 *
 * Because this object is typed as the FULL CheckoutLocators interface, the
 * compiler forces every key to exist here. Brands override only what differs.
 *
 * NOTE: the concrete selectors below target the SauceDemo demo storefront so the
 * scaffold runs green immediately. When you wire a real brand, you DO NOT edit
 * this file — you add a brand override (see locators/brands/anntaylor).
 */
export const checkoutBaseLocators: CheckoutLocators = {
  // --- Discovery / header (SauceDemo has no search; we stub to the inventory list) ---
  headerSearchInput: (page: Page) => page.locator('.product_sort_container'),
  headerSearchSubmit: (page: Page) => page.locator('.product_sort_container'),

  // --- PLP ---
  plpProductTile: (page: Page) => page.locator('.inventory_item_name'),
  plpAddToCartButton: (page: Page) => page.locator('.inventory_item button'),

  // --- PDP ---
  pdpProductName: (page: Page) => page.locator('.inventory_details_name'),
  pdpSizeOption: (page: Page) => page.locator('.inventory_details'),
  pdpAddToCartButton: (page: Page) => page.locator('button[id^="add-to-cart"]'),
  pdpGoToCartLink: (page: Page) => page.locator('.shopping_cart_link'),

  // --- Cart ---
  cartProductName: (page: Page) => page.locator('.inventory_item_name'),
  cartProductPrice: (page: Page) => page.locator('.inventory_item_price'),
  cartCheckoutButton: (page: Page) => page.locator('#checkout'),

  // --- Checkout: identification (SauceDemo has no guest gate) ---
  checkoutAsGuestButton: (page: Page) => page.locator('#checkout'),

  // --- Checkout: shipping (SauceDemo uses a minimal info form) ---
  inpFirstName: (page: Page) => page.locator('#first-name'),
  inpLastName: (page: Page) => page.locator('#last-name'),
  inpEmail: (page: Page) => page.locator('#first-name'), // demo has no email field
  inpAddress1: (page: Page) => page.locator('#postal-code'),
  inpZipCode: (page: Page) => page.locator('#postal-code'),
  inpCity: (page: Page) => page.locator('#postal-code'),
  drpState: (page: Page) => page.locator('#postal-code'),
  inpPhone: (page: Page) => page.locator('#postal-code'),
  btnContinueShipping: (page: Page) => page.locator('#continue'),

  paymentSectionReady: (page: Page) => page.locator('.summary_info'),
  shippingError: (page: Page) => page.locator('.error-message-container'),

  // --- Checkout: payment (SauceDemo has no real payment; strategy will no-op) ---
  radCreditCard: (page: Page) => page.locator('.summary_info'),
  inpCardNumber: (page: Page) => page.locator('.summary_info'),
  inpCardName: (page: Page) => page.locator('.summary_info'),
  drpCardExpMonth: (page: Page) => page.locator('.summary_info'),
  drpCardExpYear: (page: Page) => page.locator('.summary_info'),
  inpCardCvv: (page: Page) => page.locator('.summary_info'),
  btnContinueBilling: (page: Page) => page.locator('#finish'),

  placeOrderReady: (page: Page) => page.locator('#finish'),
  billingError: (page: Page) => page.locator('.error-message-container'),

  // --- Order confirmation ---
  btnPlaceOrder: (page: Page) => page.locator('#finish'),
  orderConfirmationId: (page: Page) => page.locator('.complete-header'),
};
