import { Page } from '@playwright/test';
import { BrandConfig } from '../config/brands';
import { createCheckoutPage } from '../page-objects/base/checkoutFactory';
import { ShippingAddress } from '../page-objects/base/BaseCheckoutPage';
import { CardDetails } from '../page-objects/payments/PaymentStrategy';

/**
 * Scenario layer: the "what", brand-agnostic. These journeys read like the user
 * intent and never mention a selector or a platform. They're written ONCE and
 * run against any brand. The factory below resolves the right platform bodies
 * and payment strategy under the hood.
 */
export class CheckoutScenarios {
  private readonly checkout;

  constructor(page: Page, brand: BrandConfig) {
    this.checkout = createCheckoutPage(page, brand);
  }

  /** Guest browses, adds a product, and reaches the cart. (Green on demo + live.) */
  async browseAndAddToCart(): Promise<string> {
    await this.checkout.openFirstProductFromPLP();
    const name = await this.checkout.getProductName();
    await this.checkout.addToCart();
    await this.checkout.goToCart();
    return name;
  }

  /** Full guest checkout. Reaches order confirmation on demo; stops at payment on
   *  live retail sites until a valid sandbox card is supplied. */
  async guestCheckout(address: ShippingAddress, card: CardDetails): Promise<string> {
    await this.checkout.proceedToCheckout();
    await this.checkout.checkoutAsGuest();
    await this.checkout.enterShippingAddress(address);
    await this.checkout.continueShipping();
    await this.checkout.pay(card);
    await this.checkout.placeOrder();
    return this.checkout.getOrderConfirmation();
  }
}
