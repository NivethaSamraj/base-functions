import { test as base } from '@playwright/test';
import { activeBrand, BrandConfig } from '../config/brands';

/**
 * Extends Playwright's test with the active brand, so specs stay brand-agnostic
 * and pick up whichever brand BRAND= selects at runtime.
 */
export const test = base.extend<{ brand: BrandConfig }>({
  brand: async ({}, use) => {
    await use(activeBrand());
  },
});

export { expect } from '@playwright/test';
