import { ShippingAddress } from '../page-objects/base/BaseCheckoutPage';
import { CardDetails } from '../page-objects/payments/PaymentStrategy';

export const GUEST_ADDRESS: ShippingAddress = {
  firstName: 'Rahul',
  lastName: 'Test',
  email: 'qa.guest@example.com',
  address1: '100 Test Street',
  zipCode: '28202',
  city: 'Charlotte',
  state: 'NC',
  phone: '6175551234',
};

// NOTE: 4111... is a generic test PAN; real Aurus envs reject it.
// Replace with the brand's sandbox card before expecting a live green.
export const TEST_CARD: CardDetails = {
  nameOnCard: 'Rahul Test',
  cardNumber: '4111111111111111',
  expMonth: '08',
  expYear: '2026',
  cvv: '283',
};

// Demo storefront credentials (SauceDemo).
export const DEMO_USER = { username: 'standard_user', password: 'secret_sauce' };
