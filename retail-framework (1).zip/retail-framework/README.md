# Multi-Brand Retail Automation Framework (Playwright + TypeScript)

A scalable framework for running the same test scenarios across many retail
brands on mixed platforms, writing each piece of behaviour as few times as the
variation actually demands.

## The architecture in one picture

```
tests/                     run the journeys (brand picked by BRAND= env var)
  │
scenarios/                 the "what" — brand-agnostic journeys, written ONCE
  │
page-objects/base/         the "how" — method BODIES (Shared + Override) written ONCE
  │                        payment delegated to a strategy (Brand-specific)
  │
locators/registry/         merges base + brand override (spread, last-write-wins)
  │                        TYPED against CheckoutLocators -> typos = compile error
  ▼
locators/base/             default selector for every key
locators/brands/<brand>/   ONLY the selectors that differ for that brand
```

### The three reuse buckets
- **Shared** — key defined only in base; no brand override. Written once.
  (SauceDemo's override file is empty — every key is Shared.)
- **Override** — same method body; brand redefines only the *selector*.
  (Most of checkout: see `locators/brands/anntaylor/`.)
- **Brand-specific** — flow itself differs; injected as a `PaymentStrategy`.
  (`SfccAurusPayment` vs `DemoNoOpPayment`.)

## Setup

```bash
npm install
npx playwright install chromium
```

## Run

```bash
npm run test:saucedemo     # reference brand — runs green end to end
npm run test:anntaylor     # live brand (fill selectors first; see below)
npm run report             # open the HTML report
```

The `BRAND` env var selects the brand; `baseURL`, page bodies, and payment
strategy all follow from its `platform` in `config/brands.ts`.

## Add a brand (5 steps)

1. **Config**: add an entry to `BRANDS` in `config/brands.ts` (id, platform, baseUrl).
2. **Override file**: create `locators/brands/<id>/checkoutLocators.ts` exporting
   a `BrandLocatorOverride`. Fill ONLY the keys whose selectors differ from base.
3. **Register it**: import that override and add one line to `BRAND_OVERRIDES`
   in `locators/registry/LocatorRegistry.ts`.
4. **Payment** (only if a new platform): add a `PaymentStrategy` implementation
   and one `case` in `page-objects/base/checkoutFactory.ts`.
5. **Run**: `BRAND=<id> npx playwright test`.

You never touch the scenario layer or the base page bodies to add a brand —
that's the whole point.

## Filling real selectors

For each `// TODO` in a brand override, inspect the live element, copy its
`outerHTML`, and replace the placeholder with a selector that matches it.
Prefer stable hooks (ids, `data-*`, roles) over brittle class chains.

## Honest limitations
- Live retail checkout cannot place a real order without a valid sandbox
  payment method. The card flow is built and fails *fast with a reason*; it
  does not fake success.
- Some sites bot-block automation; pasted `outerHTML` is the reliable way to
  get real selectors.
