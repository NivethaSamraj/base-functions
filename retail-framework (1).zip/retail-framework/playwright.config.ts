import 'dotenv/config';
import { defineConfig, devices } from '@playwright/test';
import { activeBrand } from './config/brands';

const brand = activeBrand();

export default defineConfig({
  testDir: './tests',
  timeout: 90_000,
  expect: { timeout: 15_000 },
  fullyParallel: false,
  retries: process.env.CI ? 1 : 0,
  workers: 1,
  reporter: [['list'], ['html', { open: 'never' }]],
  use: {
    baseURL: brand.baseUrl,
    httpCredentials: brand.basicAuth, // satisfies the staging Basic Auth popup
    headless: true,
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    trace: 'retain-on-failure',
    actionTimeout: 30_000,
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
  ],
});
