import { Page } from '@playwright/test';
import { BaseCheckoutPage } from './BaseCheckoutPage';
import { BrandConfig } from '../../config/brands';
import { PaymentStrategy } from '../payments/PaymentStrategy';
import { SfccAurusPayment } from '../payments/SfccAurusPayment';
import { DemoNoOpPayment } from '../payments/DemoNoOpPayment';

/**
 * Picks the right payment strategy for the brand's platform. This is the only
 * place platform -> behaviour mapping lives. Adding a platform = one case here.
 */
function paymentFor(brand: BrandConfig): PaymentStrategy {
  switch (brand.platform) {
    case 'sfcc':
      return new SfccAurusPayment();
    case 'demo':
      return new DemoNoOpPayment();
    case 'other':
      // return new OtherPlatformPayment();
      return new DemoNoOpPayment(); // placeholder until wired
    default:
      return new DemoNoOpPayment();
  }
}

export function createCheckoutPage(page: Page, brand: BrandConfig): BaseCheckoutPage {
  return new BaseCheckoutPage(page, brand.id, paymentFor(brand));
}
