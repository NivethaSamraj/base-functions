import { Page } from '@playwright/test';
import { HomeLocators } from '../contracts/HomeLocators';

/** BASE selectors for Home (SauceDemo defaults so the scaffold runs green). */
export const homeBaseLocators: HomeLocators = {
  searchInput: (page: Page) => page.locator('.product_sort_container'),
  searchSubmit: (page: Page) => page.locator('.product_sort_container'),
  categoryNavLink: (page: Page) => page.locator('.app_logo'),
};
