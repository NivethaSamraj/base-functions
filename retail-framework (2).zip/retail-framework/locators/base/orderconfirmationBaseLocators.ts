import { Page } from '@playwright/test';
import { OrderConfirmationLocators } from '../contracts/OrderConfirmationLocators';

/** BASE selectors for OrderConfirmation (SauceDemo defaults so the scaffold runs green). */
export const orderconfirmationBaseLocators: OrderConfirmationLocators = {
  confirmationHeader: (page: Page) => page.locator('.complete-header'),
  orderNumber: (page: Page) => page.locator('.complete-text'),
};
