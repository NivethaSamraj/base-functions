import { Page } from '@playwright/test';
import { CartLocators } from '../contracts/CartLocators';

/** BASE selectors for Cart (SauceDemo defaults so the scaffold runs green). */
export const cartBaseLocators: CartLocators = {
  lineItemName: (page: Page) => page.locator('.inventory_item_name'),
  lineItemPrice: (page: Page) => page.locator('.inventory_item_price'),
  checkoutButton: (page: Page) => page.locator('#checkout'),
};
