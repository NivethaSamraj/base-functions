import { Page } from '@playwright/test';
import { SearchResultsLocators } from '../contracts/SearchResultsLocators';

/** BASE selectors for SearchResults (SauceDemo defaults so the scaffold runs green). */
export const searchresultsBaseLocators: SearchResultsLocators = {
  resultTile: (page: Page) => page.locator('.inventory_item_name'),
  resultCount: (page: Page) => page.locator('.inventory_item'),
};
