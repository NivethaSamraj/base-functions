import { Page } from '@playwright/test';
import { PdpLocators } from '../contracts/PDPLocators';

/** BASE selectors for PDP (SauceDemo defaults so the scaffold runs green). */
export const pdpBaseLocators: PdpLocators = {
  productName: (page: Page) => page.locator('.inventory_details_name'),
  sizeOption: (page: Page) => page.locator('.inventory_details'),
  addToCart: (page: Page) => page.locator('button[id^="add-to-cart"]'),
  goToCartLink: (page: Page) => page.locator('.shopping_cart_link'),
};
