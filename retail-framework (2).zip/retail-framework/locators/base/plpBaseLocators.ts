import { Page } from '@playwright/test';
import { PlpLocators } from '../contracts/PLPLocators';

/** BASE selectors for PLP (SauceDemo defaults so the scaffold runs green). */
export const plpBaseLocators: PlpLocators = {
  productTile: (page: Page) => page.locator('.inventory_item_name'),
  addToCartOnTile: (page: Page) => page.locator('.inventory_item button'),
  sortDropdown: (page: Page) => page.locator('.product_sort_container'),
};
