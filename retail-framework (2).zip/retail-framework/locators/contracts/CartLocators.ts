import { Page, Locator } from '@playwright/test';

export type LocatorFactory = (page: Page) => Locator;

/** Locator contract for the Cart page. Base implements all; brands override a subset. */
export interface CartLocators {
  lineItemName: LocatorFactory;
  lineItemPrice: LocatorFactory;
  checkoutButton: LocatorFactory;
}

export type CartLocatorsOverride = Partial<CartLocators>;
