import { Page, Locator } from '@playwright/test';

export type LocatorFactory = (page: Page) => Locator;

/** Locator contract for the SearchResults page. Base implements all; brands override a subset. */
export interface SearchResultsLocators {
  resultTile: LocatorFactory;
  resultCount: LocatorFactory;
}

export type SearchResultsLocatorsOverride = Partial<SearchResultsLocators>;
