import { Page, Locator } from '@playwright/test';

export type LocatorFactory = (page: Page) => Locator;

/** Locator contract for the Home page. Base implements all; brands override a subset. */
export interface HomeLocators {
  searchInput: LocatorFactory;
  searchSubmit: LocatorFactory;
  categoryNavLink: LocatorFactory;
}

export type HomeLocatorsOverride = Partial<HomeLocators>;
