import { Page, Locator } from '@playwright/test';

export type LocatorFactory = (page: Page) => Locator;

/** Locator contract for the OrderConfirmation page. Base implements all; brands override a subset. */
export interface OrderConfirmationLocators {
  confirmationHeader: LocatorFactory;
  orderNumber: LocatorFactory;
}

export type OrderConfirmationLocatorsOverride = Partial<OrderConfirmationLocators>;
