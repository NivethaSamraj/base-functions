import { Page, Locator } from '@playwright/test';

export type LocatorFactory = (page: Page) => Locator;

/** Locator contract for the PLP page. Base implements all; brands override a subset. */
export interface PlpLocators {
  productTile: LocatorFactory;
  addToCartOnTile: LocatorFactory;
  sortDropdown: LocatorFactory;
}

export type PlpLocatorsOverride = Partial<PlpLocators>;
