import { Page, Locator } from '@playwright/test';

export type LocatorFactory = (page: Page) => Locator;

/** Locator contract for the PDP page. Base implements all; brands override a subset. */
export interface PdpLocators {
  productName: LocatorFactory;
  sizeOption: LocatorFactory;
  addToCart: LocatorFactory;
  goToCartLink: LocatorFactory;
}

export type PdpLocatorsOverride = Partial<PdpLocators>;
