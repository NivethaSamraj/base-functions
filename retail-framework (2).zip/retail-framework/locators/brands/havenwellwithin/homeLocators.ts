import { Page } from '@playwright/test';
import { HomeLocatorsOverride } from '../../contracts/HomeLocators';

export const havenwellwithinHomeLocators: HomeLocatorsOverride = {
  searchInput: (page: Page) => page.locator('TODO_havenwellwithin_searchInput'), // input string
  searchSubmit: (page: Page) => page.locator('TODO_havenwellwithin_searchSubmit'), // submit
  categoryNavLink: (page: Page) => page.locator('TODO_havenwellwithin_categoryNavLink'), // nav link
};
