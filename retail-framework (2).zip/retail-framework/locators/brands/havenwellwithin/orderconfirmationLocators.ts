import { Page } from '@playwright/test';
import { OrderConfirmationLocatorsOverride } from '../../contracts/OrderConfirmationLocators';

export const havenwellwithinOrderConfirmationLocators: OrderConfirmationLocatorsOverride = {
  confirmationHeader: (page: Page) => page.locator('TODO_havenwellwithin_confirmationHeader'), // thank you
  orderNumber: (page: Page) => page.locator('TODO_havenwellwithin_orderNumber'), // order id
};
