import { Page } from '@playwright/test';
import { PdpLocatorsOverride } from '../../contracts/PDPLocators';

export const havenwellwithinPDPLocators: PdpLocatorsOverride = {
  productName: (page: Page) => page.locator('TODO_havenwellwithin_productName'), // h1 name
  sizeOption: (page: Page) => page.locator('TODO_havenwellwithin_sizeOption'), // size swatch
  addToCart: (page: Page) => page.locator('TODO_havenwellwithin_addToCart'), // add to bag
  goToCartLink: (page: Page) => page.locator('TODO_havenwellwithin_goToCartLink'), // minicart
};
