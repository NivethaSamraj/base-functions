import { Page } from '@playwright/test';
import { SearchResultsLocatorsOverride } from '../../contracts/SearchResultsLocators';

export const havenwellwithinSearchResultsLocators: SearchResultsLocatorsOverride = {
  resultTile: (page: Page) => page.locator('TODO_havenwellwithin_resultTile'), // product link
  resultCount: (page: Page) => page.locator('TODO_havenwellwithin_resultCount'), // count label
};
