import { Page } from '@playwright/test';
import { PlpLocatorsOverride } from '../../contracts/PLPLocators';

export const havenwellwithinPLPLocators: PlpLocatorsOverride = {
  productTile: (page: Page) => page.locator('TODO_havenwellwithin_productTile'), // tile link
  addToCartOnTile: (page: Page) => page.locator('TODO_havenwellwithin_addToCartOnTile'), // quick add
  sortDropdown: (page: Page) => page.locator('TODO_havenwellwithin_sortDropdown'), // sort
};
