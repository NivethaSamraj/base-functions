import { Page } from '@playwright/test';
import { CartLocatorsOverride } from '../../contracts/CartLocators';

export const havenwellwithinCartLocators: CartLocatorsOverride = {
  lineItemName: (page: Page) => page.locator('TODO_havenwellwithin_lineItemName'), // item name
  lineItemPrice: (page: Page) => page.locator('TODO_havenwellwithin_lineItemPrice'), // item price
  checkoutButton: (page: Page) => page.locator('TODO_havenwellwithin_checkoutButton'), // checkout
};
