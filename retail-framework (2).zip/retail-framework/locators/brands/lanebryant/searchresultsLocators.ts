import { Page } from '@playwright/test';
import { SearchResultsLocatorsOverride } from '../../contracts/SearchResultsLocators';

/** Lane Bryant Search Results — VERIFIED selectors (SFCC). */
export const lanebryantSearchResultsLocators: SearchResultsLocatorsOverride = {
  // Product tile image link inside results grid.
  resultTile: (page: Page) => page.locator('.product-tile img.tile-image').first(),

  // <span class="results-value">137 items</span>
  resultCount: (page: Page) => page.locator('.results-value'),
};
