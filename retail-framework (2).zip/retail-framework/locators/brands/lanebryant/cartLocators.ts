import { Page } from '@playwright/test';
import { CartLocatorsOverride } from '../../contracts/CartLocators';

/**
 * Lane Bryant Cart — checkout button is EShopWorld (international path).
 * <a id="esw-checkout-btn" class="btn-Checkout ...">Checkout</a>
 */
export const lanebryantCartLocators: CartLocatorsOverride = {
  // TODO confirm line-item selectors from cart-page outerHTML
  lineItemName: (page: Page) => page.locator('.line-item-name, .product-line-item .item-name').first(),
  lineItemPrice: (page: Page) => page.locator('.line-item-total-price .value, .pricing').first(),

  // ESW checkout button (verified).
  checkoutButton: (page: Page) => page.locator('#esw-checkout-btn, a.btn-Checkout').first(),
};
