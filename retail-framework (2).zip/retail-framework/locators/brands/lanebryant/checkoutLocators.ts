import { Page } from '@playwright/test';
import { CheckoutLocators } from '../../registry/locatorTypes';

/**
 * Lane Bryant CHECKOUT — EShopWorld (ESW), NOT native SFCC/Aurus.
 *
 * Evidence from staging: INR pricing, Province/Locality/Country=India,
 * #esw-checkout-btn, and a "Continue to payment" div
 * (data-id="continue_to_payment_button_click_CTA"). ESW owns checkout+payment.
 *
 * Field LABELS are known (from the rendered form); field IDs are still TODO —
 * inspect each input and replace. Selectors below use label-based fallbacks that
 * often work, but verify.
 */
export const lanebryantLocators: Partial<CheckoutLocators> = {
  // No SFCC guest gate on ESW; checkout starts after #esw-checkout-btn.
  checkoutAsGuestButton: (page: Page) => page.locator('#esw-checkout-btn, a.btn-Checkout').first(),

  // --- ESW Delivery Address form (labels verified; IDs TODO) ---
  inpFirstName: (page: Page) => page.getByLabel(/First Name/i),
  inpLastName: (page: Page) => page.getByLabel(/Last Name/i),
  inpEmail: (page: Page) => page.getByLabel(/Email/i),                 // TODO: ESW may collect email elsewhere
  inpAddress1: (page: Page) => page.getByLabel(/Address Line 1/i),
  inpCity: (page: Page) => page.getByLabel(/Locality/i),               // ESW calls city "Locality"
  drpState: (page: Page) => page.getByLabel(/Province/i),              // ESW calls state "Province"
  inpZipCode: (page: Page) => page.getByLabel(/Postal Code/i),
  inpPhone: (page: Page) => page.getByLabel(/Phone/i),                 // TODO: confirm phone field exists/label

  // "Continue to payment" — a div, not a button.
  btnContinueShipping: (page: Page) =>
    page.locator('[data-id="continue_to_payment_button_click_CTA"]'),

  paymentSectionReady: (page: Page) =>
    page.locator('[data-id*="payment"], iframe[src*="payment"], #eswCheckoutForm').first(), // TODO verify
  shippingError: (page: Page) =>
    page.locator('.field-validation-error, .esw-error, .alert-danger').first(),             // TODO verify

  // --- ESW payment (almost certainly an IFRAME — needs frameLocator once known) ---
  radCreditCard: (page: Page) => page.locator('[data-id*="card"], input[value*="CARD"]').first(),   // TODO
  inpCardNumber: (page: Page) => page.locator('#cardNumber, input[name*="cardNumber"]'),            // TODO iframe?
  inpCardName: (page: Page) => page.locator('#cardHolderName, input[name*="holder"]'),              // TODO
  drpCardExpMonth: (page: Page) => page.locator('#expiryMonth, select[name*="month"]'),             // TODO
  drpCardExpYear: (page: Page) => page.locator('#expiryYear, select[name*="year"]'),                // TODO
  inpCardCvv: (page: Page) => page.locator('#cvv, input[name*="cvv"], input[name*="securityCode"]'),// TODO
  btnContinueBilling: (page: Page) =>
    page.locator('[data-id*="place_order"], [data-id*="pay_now"], button[type="submit"]').first(),  // TODO

  placeOrderReady: (page: Page) => page.locator('.order-confirmation, [data-id*="confirmation"]').first(), // TODO
  billingError: (page: Page) => page.locator('.field-validation-error, .esw-error').first(),        // TODO

  btnPlaceOrder: (page: Page) =>
    page.locator('[data-id*="place_order"], [data-id*="pay_now"]').first(),                          // TODO

  orderConfirmationId: (page: Page) => page.locator('.order-number, [data-id*="order_number"]').first(), // TODO
};
