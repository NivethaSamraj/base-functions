import { Page } from '@playwright/test';
import { PdpLocatorsOverride } from '../../contracts/PDPLocators';

/**
 * Lane Bryant PDP — VERIFIED selectors (from live staging outerHTML).
 *
 * Platform note: storefront/PDP is SFCC, but CHECKOUT is EShopWorld (ESW) on the
 * international path — see checkoutLocators.ts. PDP selectors below are stable.
 */
export const lanebryantPDPLocators: PdpLocatorsOverride = {
  // <h1 class="product-name bfx-product-name">Swing V-Neck Tank</h1>
  productName: (page: Page) => page.locator('h1.product-name'),

  // Size buttons: only SELECTABLE ones are clickable. unselectable/d-none are
  // out of stock or hidden, so exclude them to avoid clicking a dead size.
  sizeOption: (page: Page) =>
    page.locator('button.non-color-attribute.selectable:not(.unselectable):not(.d-none)'),

  // <button class="add-to-cart ... add-to-cart-button ...">Add to Bag</button>
  addToCart: (page: Page) =>
    page.locator('button.add-to-cart-button, button.add-to-cart').first(),

  // <a class="minicart-link" href=".../cart">
  goToCartLink: (page: Page) => page.locator('a.minicart-link'),
};
