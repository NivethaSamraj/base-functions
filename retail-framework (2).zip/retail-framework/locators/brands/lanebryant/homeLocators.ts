import { Page } from '@playwright/test';
import { HomeLocatorsOverride } from '../../contracts/HomeLocators';

/** Lane Bryant Home/Header — VERIFIED selectors (SFCC storefront). */
export const lanebryantHomeLocators: HomeLocatorsOverride = {
  // <input class="search-field" type="search" name="q" ...>
  searchInput: (page: Page) => page.locator('input.search-field[name="q"]').first(),

  // <button type="submit" name="search-button" class="home-search ...">
  searchSubmit: (page: Page) => page.locator('button[name="search-button"]').first(),

  // <a id="cat10016" class="nav-link ...">Clothing</a>
  categoryNavLink: (page: Page) => page.locator('a.nav-link[id^="cat"]').first(),
};
