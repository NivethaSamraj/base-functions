import { Page } from '@playwright/test';
import { PlpLocatorsOverride } from '../../contracts/PLPLocators';

/** Lane Bryant PLP — VERIFIED selectors (SFCC). */
export const lanebryantPLPLocators: PlpLocatorsOverride = {
  // Tile image (clicking opens PDP). Stable across category pages.
  productTile: (page: Page) => page.locator('.product-tile img.tile-image').first(),

  // Sort dropdown (SFCC standard). TODO: confirm exact selector if custom.
  sortDropdown: (page: Page) => page.locator('select.custom-select[name="sort-order"], .product-sort select').first(),
};
