import { Page } from '@playwright/test';
import { OrderConfirmationLocatorsOverride } from '../../contracts/OrderConfirmationLocators';

export const lanebryantOrderConfirmationLocators: OrderConfirmationLocatorsOverride = {
  confirmationHeader: (page: Page) => page.locator('TODO_lanebryant_confirmationHeader'), // thank you
  orderNumber: (page: Page) => page.locator('TODO_lanebryant_orderNumber'), // order id
};
