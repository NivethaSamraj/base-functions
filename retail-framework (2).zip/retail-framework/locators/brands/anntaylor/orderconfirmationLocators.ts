import { Page } from '@playwright/test';
import { OrderConfirmationLocatorsOverride } from '../../contracts/OrderConfirmationLocators';

export const anntaylorOrderConfirmationLocators: OrderConfirmationLocatorsOverride = {
  confirmationHeader: (page: Page) => page.locator('TODO_anntaylor_confirmationHeader'), // thank you
  orderNumber: (page: Page) => page.locator('TODO_anntaylor_orderNumber'), // order id
};
