import { Page } from '@playwright/test';
import { CartLocatorsOverride } from '../../contracts/CartLocators';

export const anntaylorCartLocators: CartLocatorsOverride = {
  lineItemName: (page: Page) => page.locator('TODO_anntaylor_lineItemName'), // item name
  lineItemPrice: (page: Page) => page.locator('TODO_anntaylor_lineItemPrice'), // item price
  checkoutButton: (page: Page) => page.locator('TODO_anntaylor_checkoutButton'), // checkout
};
