import { Page } from '@playwright/test';
import { HomeLocatorsOverride } from '../../contracts/HomeLocators';

export const anntaylorHomeLocators: HomeLocatorsOverride = {
  searchInput: (page: Page) => page.locator('TODO_anntaylor_searchInput'), // input string
  searchSubmit: (page: Page) => page.locator('TODO_anntaylor_searchSubmit'), // submit
  categoryNavLink: (page: Page) => page.locator('TODO_anntaylor_categoryNavLink'), // nav link
};
