import { Page } from '@playwright/test';
import { SearchResultsLocatorsOverride } from '../../contracts/SearchResultsLocators';

export const anntaylorSearchResultsLocators: SearchResultsLocatorsOverride = {
  resultTile: (page: Page) => page.locator('TODO_anntaylor_resultTile'), // product link
  resultCount: (page: Page) => page.locator('TODO_anntaylor_resultCount'), // count label
};
