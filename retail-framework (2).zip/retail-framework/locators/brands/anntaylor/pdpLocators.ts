import { Page } from '@playwright/test';
import { PdpLocatorsOverride } from '../../contracts/PDPLocators';

export const anntaylorPDPLocators: PdpLocatorsOverride = {
  productName: (page: Page) => page.locator('TODO_anntaylor_productName'), // h1 name
  sizeOption: (page: Page) => page.locator('TODO_anntaylor_sizeOption'), // size swatch
  addToCart: (page: Page) => page.locator('TODO_anntaylor_addToCart'), // add to bag
  goToCartLink: (page: Page) => page.locator('TODO_anntaylor_goToCartLink'), // minicart
};
