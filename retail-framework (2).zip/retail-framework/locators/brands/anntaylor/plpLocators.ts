import { Page } from '@playwright/test';
import { PlpLocatorsOverride } from '../../contracts/PLPLocators';

export const anntaylorPLPLocators: PlpLocatorsOverride = {
  productTile: (page: Page) => page.locator('TODO_anntaylor_productTile'), // tile link
  addToCartOnTile: (page: Page) => page.locator('TODO_anntaylor_addToCartOnTile'), // quick add
  sortDropdown: (page: Page) => page.locator('TODO_anntaylor_sortDropdown'), // sort
};
