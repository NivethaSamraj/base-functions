import { PlpLocatorsOverride } from '../../contracts/PLPLocators';

export const saucedemoPLPLocators: PlpLocatorsOverride = {
  // empty — SauceDemo uses base as-is (all Shared)
};
