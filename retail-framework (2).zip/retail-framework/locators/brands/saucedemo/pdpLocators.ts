import { PdpLocatorsOverride } from '../../contracts/PDPLocators';

export const saucedemoPDPLocators: PdpLocatorsOverride = {
  // empty — SauceDemo uses base as-is (all Shared)
};
