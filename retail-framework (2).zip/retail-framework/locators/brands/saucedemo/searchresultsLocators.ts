import { SearchResultsLocatorsOverride } from '../../contracts/SearchResultsLocators';

export const saucedemoSearchResultsLocators: SearchResultsLocatorsOverride = {
  // empty — SauceDemo uses base as-is (all Shared)
};
