import { HomeLocatorsOverride } from '../../contracts/HomeLocators';

export const saucedemoHomeLocators: HomeLocatorsOverride = {
  // empty — SauceDemo uses base as-is (all Shared)
};
