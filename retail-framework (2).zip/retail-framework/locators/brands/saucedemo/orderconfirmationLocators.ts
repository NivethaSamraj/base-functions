import { OrderConfirmationLocatorsOverride } from '../../contracts/OrderConfirmationLocators';

export const saucedemoOrderConfirmationLocators: OrderConfirmationLocatorsOverride = {
  // empty — SauceDemo uses base as-is (all Shared)
};
