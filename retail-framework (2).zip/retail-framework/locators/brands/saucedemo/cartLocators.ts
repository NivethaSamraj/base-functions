import { CartLocatorsOverride } from '../../contracts/CartLocators';

export const saucedemoCartLocators: CartLocatorsOverride = {
  // empty — SauceDemo uses base as-is (all Shared)
};
