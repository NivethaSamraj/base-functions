import { Page } from '@playwright/test';
import { SearchResultsLocatorsOverride } from '../../contracts/SearchResultsLocators';

export const talbotsSearchResultsLocators: SearchResultsLocatorsOverride = {
  resultTile: (page: Page) => page.locator('TODO_talbots_resultTile'), // product link
  resultCount: (page: Page) => page.locator('TODO_talbots_resultCount'), // count label
};
