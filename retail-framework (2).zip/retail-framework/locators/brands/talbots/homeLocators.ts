import { Page } from '@playwright/test';
import { HomeLocatorsOverride } from '../../contracts/HomeLocators';

export const talbotsHomeLocators: HomeLocatorsOverride = {
  searchInput: (page: Page) => page.locator('TODO_talbots_searchInput'), // input string
  searchSubmit: (page: Page) => page.locator('TODO_talbots_searchSubmit'), // submit
  categoryNavLink: (page: Page) => page.locator('TODO_talbots_categoryNavLink'), // nav link
};
