import { Page } from '@playwright/test';
import { PdpLocatorsOverride } from '../../contracts/PDPLocators';

export const talbotsPDPLocators: PdpLocatorsOverride = {
  productName: (page: Page) => page.locator('TODO_talbots_productName'), // h1 name
  sizeOption: (page: Page) => page.locator('TODO_talbots_sizeOption'), // size swatch
  addToCart: (page: Page) => page.locator('TODO_talbots_addToCart'), // add to bag
  goToCartLink: (page: Page) => page.locator('TODO_talbots_goToCartLink'), // minicart
};
