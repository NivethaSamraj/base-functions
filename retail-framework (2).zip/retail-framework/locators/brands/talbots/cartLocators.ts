import { Page } from '@playwright/test';
import { CartLocatorsOverride } from '../../contracts/CartLocators';

export const talbotsCartLocators: CartLocatorsOverride = {
  lineItemName: (page: Page) => page.locator('TODO_talbots_lineItemName'), // item name
  lineItemPrice: (page: Page) => page.locator('TODO_talbots_lineItemPrice'), // item price
  checkoutButton: (page: Page) => page.locator('TODO_talbots_checkoutButton'), // checkout
};
