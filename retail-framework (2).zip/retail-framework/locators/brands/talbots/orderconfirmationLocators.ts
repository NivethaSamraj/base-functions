import { Page } from '@playwright/test';
import { OrderConfirmationLocatorsOverride } from '../../contracts/OrderConfirmationLocators';

export const talbotsOrderConfirmationLocators: OrderConfirmationLocatorsOverride = {
  confirmationHeader: (page: Page) => page.locator('TODO_talbots_confirmationHeader'), // thank you
  orderNumber: (page: Page) => page.locator('TODO_talbots_orderNumber'), // order id
};
