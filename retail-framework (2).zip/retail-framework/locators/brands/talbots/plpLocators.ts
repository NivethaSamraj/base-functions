import { Page } from '@playwright/test';
import { PlpLocatorsOverride } from '../../contracts/PLPLocators';

export const talbotsPLPLocators: PlpLocatorsOverride = {
  productTile: (page: Page) => page.locator('TODO_talbots_productTile'), // tile link
  addToCartOnTile: (page: Page) => page.locator('TODO_talbots_addToCartOnTile'), // quick add
  sortDropdown: (page: Page) => page.locator('TODO_talbots_sortDropdown'), // sort
};
