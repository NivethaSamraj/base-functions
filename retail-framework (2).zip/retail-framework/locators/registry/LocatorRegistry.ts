import { CheckoutLocators } from './locatorTypes';
import { checkoutBaseLocators } from '../base/checkoutBaseLocators';
import { saucedemoLocators } from '../brands/saucedemo/checkoutLocators';
import { anntaylorLocators } from '../brands/anntaylor/checkoutLocators';
import { talbotsLocators } from '../brands/talbots/checkoutLocators';
import { lanebryantLocators } from '../brands/lanebryant/checkoutLocators';
import { havenwellwithinLocators } from '../brands/havenwellwithin/checkoutLocators';

/**
 * Maps each brand id to its override object. To add a brand: import its
 * override and add one line here.
 */
const BRAND_OVERRIDES = {
  saucedemo: saucedemoLocators,
  anntaylor: anntaylorLocators,
  talbots: talbotsLocators,
  lanebryant: lanebryantLocators,
  havenwellwithin: havenwellwithinLocators,
} as const;

/**
 * Build the effective locator set for a brand.
 *
 * THIS is the override mechanism: spread base first, then the brand override.
 * Last-write-wins means any key the brand redefines shadows the base; any key
 * it omits falls through to base. Because both sides are typed against
 * CheckoutLocators, the result is guaranteed to satisfy the full contract.
 */
export function getLocators(brandId: string): CheckoutLocators {
  const override = (BRAND_OVERRIDES as Record<string, object>)[brandId] ?? {};
  return { ...checkoutBaseLocators, ...override };
}
