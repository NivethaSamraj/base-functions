import { HomeLocators } from '../contracts/HomeLocators';
import { homeBaseLocators } from '../base/homeBaseLocators';
import { saucedemoHomeLocators } from '../brands/saucedemo/homeLocators';
import { anntaylorHomeLocators } from '../brands/anntaylor/homeLocators';
import { talbotsHomeLocators } from '../brands/talbots/homeLocators';
import { lanebryantHomeLocators } from '../brands/lanebryant/homeLocators';
import { havenwellwithinHomeLocators } from '../brands/havenwellwithin/homeLocators';

const OVERRIDES = {
  saucedemo: saucedemoHomeLocators,
  anntaylor: anntaylorHomeLocators,
  talbots: talbotsHomeLocators,
  lanebryant: lanebryantHomeLocators,
  havenwellwithin: havenwellwithinHomeLocators,
} as const;

export function getHomeLocators(brandId: string): HomeLocators {
  const ov = (OVERRIDES as Record<string, object>)[brandId] ?? {};
  return { ...homeBaseLocators, ...ov };
}
