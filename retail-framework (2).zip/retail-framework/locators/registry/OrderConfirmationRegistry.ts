import { OrderConfirmationLocators } from '../contracts/OrderConfirmationLocators';
import { orderconfirmationBaseLocators } from '../base/orderconfirmationBaseLocators';
import { saucedemoOrderConfirmationLocators } from '../brands/saucedemo/orderconfirmationLocators';
import { anntaylorOrderConfirmationLocators } from '../brands/anntaylor/orderconfirmationLocators';
import { talbotsOrderConfirmationLocators } from '../brands/talbots/orderconfirmationLocators';
import { lanebryantOrderConfirmationLocators } from '../brands/lanebryant/orderconfirmationLocators';
import { havenwellwithinOrderConfirmationLocators } from '../brands/havenwellwithin/orderconfirmationLocators';

const OVERRIDES = {
  saucedemo: saucedemoOrderConfirmationLocators,
  anntaylor: anntaylorOrderConfirmationLocators,
  talbots: talbotsOrderConfirmationLocators,
  lanebryant: lanebryantOrderConfirmationLocators,
  havenwellwithin: havenwellwithinOrderConfirmationLocators,
} as const;

export function getOrderConfirmationLocators(brandId: string): OrderConfirmationLocators {
  const ov = (OVERRIDES as Record<string, object>)[brandId] ?? {};
  return { ...orderconfirmationBaseLocators, ...ov };
}
