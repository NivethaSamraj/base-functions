import { PlpLocators } from '../contracts/PLPLocators';
import { plpBaseLocators } from '../base/plpBaseLocators';
import { saucedemoPLPLocators } from '../brands/saucedemo/plpLocators';
import { anntaylorPLPLocators } from '../brands/anntaylor/plpLocators';
import { talbotsPLPLocators } from '../brands/talbots/plpLocators';
import { lanebryantPLPLocators } from '../brands/lanebryant/plpLocators';
import { havenwellwithinPLPLocators } from '../brands/havenwellwithin/plpLocators';

const OVERRIDES = {
  saucedemo: saucedemoPLPLocators,
  anntaylor: anntaylorPLPLocators,
  talbots: talbotsPLPLocators,
  lanebryant: lanebryantPLPLocators,
  havenwellwithin: havenwellwithinPLPLocators,
} as const;

export function getPLPLocators(brandId: string): PlpLocators {
  const ov = (OVERRIDES as Record<string, object>)[brandId] ?? {};
  return { ...plpBaseLocators, ...ov };
}
