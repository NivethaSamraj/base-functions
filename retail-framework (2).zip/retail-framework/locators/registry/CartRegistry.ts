import { CartLocators } from '../contracts/CartLocators';
import { cartBaseLocators } from '../base/cartBaseLocators';
import { saucedemoCartLocators } from '../brands/saucedemo/cartLocators';
import { anntaylorCartLocators } from '../brands/anntaylor/cartLocators';
import { talbotsCartLocators } from '../brands/talbots/cartLocators';
import { lanebryantCartLocators } from '../brands/lanebryant/cartLocators';
import { havenwellwithinCartLocators } from '../brands/havenwellwithin/cartLocators';

const OVERRIDES = {
  saucedemo: saucedemoCartLocators,
  anntaylor: anntaylorCartLocators,
  talbots: talbotsCartLocators,
  lanebryant: lanebryantCartLocators,
  havenwellwithin: havenwellwithinCartLocators,
} as const;

export function getCartLocators(brandId: string): CartLocators {
  const ov = (OVERRIDES as Record<string, object>)[brandId] ?? {};
  return { ...cartBaseLocators, ...ov };
}
