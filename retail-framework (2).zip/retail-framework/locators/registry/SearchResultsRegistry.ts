import { SearchResultsLocators } from '../contracts/SearchResultsLocators';
import { searchresultsBaseLocators } from '../base/searchresultsBaseLocators';
import { saucedemoSearchResultsLocators } from '../brands/saucedemo/searchresultsLocators';
import { anntaylorSearchResultsLocators } from '../brands/anntaylor/searchresultsLocators';
import { talbotsSearchResultsLocators } from '../brands/talbots/searchresultsLocators';
import { lanebryantSearchResultsLocators } from '../brands/lanebryant/searchresultsLocators';
import { havenwellwithinSearchResultsLocators } from '../brands/havenwellwithin/searchresultsLocators';

const OVERRIDES = {
  saucedemo: saucedemoSearchResultsLocators,
  anntaylor: anntaylorSearchResultsLocators,
  talbots: talbotsSearchResultsLocators,
  lanebryant: lanebryantSearchResultsLocators,
  havenwellwithin: havenwellwithinSearchResultsLocators,
} as const;

export function getSearchResultsLocators(brandId: string): SearchResultsLocators {
  const ov = (OVERRIDES as Record<string, object>)[brandId] ?? {};
  return { ...searchresultsBaseLocators, ...ov };
}
