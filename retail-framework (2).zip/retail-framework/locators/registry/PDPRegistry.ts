import { PdpLocators } from '../contracts/PDPLocators';
import { pdpBaseLocators } from '../base/pdpBaseLocators';
import { saucedemoPDPLocators } from '../brands/saucedemo/pdpLocators';
import { anntaylorPDPLocators } from '../brands/anntaylor/pdpLocators';
import { talbotsPDPLocators } from '../brands/talbots/pdpLocators';
import { lanebryantPDPLocators } from '../brands/lanebryant/pdpLocators';
import { havenwellwithinPDPLocators } from '../brands/havenwellwithin/pdpLocators';

const OVERRIDES = {
  saucedemo: saucedemoPDPLocators,
  anntaylor: anntaylorPDPLocators,
  talbots: talbotsPDPLocators,
  lanebryant: lanebryantPDPLocators,
  havenwellwithin: havenwellwithinPDPLocators,
} as const;

export function getPDPLocators(brandId: string): PdpLocators {
  const ov = (OVERRIDES as Record<string, object>)[brandId] ?? {};
  return { ...pdpBaseLocators, ...ov };
}
