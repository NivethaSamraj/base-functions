import { Page } from '@playwright/test';
import { BrandConfig } from '../config/brands';
import { PageFactory } from '../page-objects/PageFactory';
import { ShippingAddress } from '../page-objects/base/BaseCheckoutPage';
import { CardDetails } from '../page-objects/payments/PaymentStrategy';

/**
 * Scenario layer: brand-agnostic journeys across the FULL funnel. Written once;
 * the PageFactory resolves the right brand page object for each step.
 */
export class CheckoutScenarios {
  private readonly pages: PageFactory;

  constructor(page: Page, brand: BrandConfig) {
    this.pages = new PageFactory(page, brand);
  }

  /** Home -> search -> PDP. Returns the product name. */
  async findProductBySearch(term: string): Promise<string> {
    await this.pages.home().search(term);
    await this.pages.searchResults().openFirstResult();
    return this.pages.pdp().getProductName();
  }

  /** PLP -> PDP -> add to cart -> cart. Returns the product name. */
  async browseAndAddToCart(): Promise<string> {
    const pdp = this.pages.pdp();
    const name = await pdp.getProductName();
    await pdp.selectFirstAvailableSize();
    await pdp.addToCart();
    await pdp.goToCart();
    return name;
  }

  /** Full guest checkout: cart -> shipping -> payment -> confirmation. */
  async guestCheckout(address: ShippingAddress, card: CardDetails): Promise<string> {
    await this.pages.cart().proceedToCheckout();
    const checkout = this.pages.checkout();
    await checkout.checkoutAsGuest();
    await checkout.enterShippingAddress(address);
    await checkout.continueShipping();
    await checkout.pay(card);
    await checkout.placeOrder();
    return this.pages.orderConfirmation().getConfirmationText();
  }
}
