import { Page } from '@playwright/test';
import { BrandConfig } from '../config/brands';
import { PaymentStrategy } from './payments/PaymentStrategy';
import { SfccAurusPayment } from './payments/SfccAurusPayment';
import { DemoNoOpPayment } from './payments/DemoNoOpPayment';

import { BaseHomePage } from './base/BaseHomePage';
import { BaseSearchResultsPage } from './base/BaseSearchResultsPage';
import { BasePLPPage } from './base/BasePLPPage';
import { BasePDPPage } from './base/BasePDPPage';
import { BaseCartPage } from './base/BaseCartPage';
import { BaseCheckoutPage } from './base/BaseCheckoutPage';
import { BaseOrderConfirmationPage } from './base/BaseOrderConfirmationPage';

// Brand seams
import { AnnTaylorHomePage } from './brands/AnnTaylorHomePage';
import { TalbotsHomePage } from './brands/TalbotsHomePage';
import { LaneBryantHomePage } from './brands/LaneBryantHomePage';
import { HavenWellWithinHomePage } from './brands/HavenWellWithinHomePage';
import { SauceDemoHomePage } from './brands/SauceDemoHomePage';
import { AnnTaylorPLPPage } from './brands/AnnTaylorPLPPage';
import { TalbotsPLPPage } from './brands/TalbotsPLPPage';
import { LaneBryantPLPPage } from './brands/LaneBryantPLPPage';
import { HavenWellWithinPLPPage } from './brands/HavenWellWithinPLPPage';
import { SauceDemoPLPPage } from './brands/SauceDemoPLPPage';
import { AnnTaylorPDPPage } from './brands/AnnTaylorPDPPage';
import { TalbotsPDPPage } from './brands/TalbotsPDPPage';
import { LaneBryantPDPPage } from './brands/LaneBryantPDPPage';
import { HavenWellWithinPDPPage } from './brands/HavenWellWithinPDPPage';
import { SauceDemoPDPPage } from './brands/SauceDemoPDPPage';
import { AnnTaylorCartPage } from './brands/AnnTaylorCartPage';
import { TalbotsCartPage } from './brands/TalbotsCartPage';
import { LaneBryantCartPage } from './brands/LaneBryantCartPage';
import { HavenWellWithinCartPage } from './brands/HavenWellWithinCartPage';
import { SauceDemoCartPage } from './brands/SauceDemoCartPage';
import { AnnTaylorSearchResultsPage } from './brands/AnnTaylorSearchResultsPage';
import { TalbotsSearchResultsPage } from './brands/TalbotsSearchResultsPage';
import { LaneBryantSearchResultsPage } from './brands/LaneBryantSearchResultsPage';
import { HavenWellWithinSearchResultsPage } from './brands/HavenWellWithinSearchResultsPage';
import { SauceDemoSearchResultsPage } from './brands/SauceDemoSearchResultsPage';
import { AnnTaylorOrderConfirmationPage } from './brands/AnnTaylorOrderConfirmationPage';
import { TalbotsOrderConfirmationPage } from './brands/TalbotsOrderConfirmationPage';
import { LaneBryantOrderConfirmationPage } from './brands/LaneBryantOrderConfirmationPage';
import { HavenWellWithinOrderConfirmationPage } from './brands/HavenWellWithinOrderConfirmationPage';
import { SauceDemoOrderConfirmationPage } from './brands/SauceDemoOrderConfirmationPage';
import { AnnTaylorCheckoutPage } from './brands/AnnTaylorCheckoutPage';
import { TalbotsCheckoutPage } from './brands/TalbotsCheckoutPage';
import { LaneBryantCheckoutPage } from './brands/LaneBryantCheckoutPage';
import { HavenWellWithinCheckoutPage } from './brands/HavenWellWithinCheckoutPage';

function pick<T>(brandId: string, map: Record<string, () => T>, base: () => T): T {
  return (map[brandId] ?? base)();
}

function paymentFor(brand: BrandConfig): PaymentStrategy {
  switch (brand.platform) {
    case 'sfcc': return new SfccAurusPayment();
    default:     return new DemoNoOpPayment();
  }
}

/**
 * One factory for the whole journey. For each page, returns the brand-specific
 * seam if one exists, else the base page object. Brands are identifiable by name
 * in every map below.
 */
export class PageFactory {
  constructor(private page: Page, private brand: BrandConfig) {}

  home(): BaseHomePage {
    return pick(this.brand.id, {
      anntaylor: () => new AnnTaylorHomePage(this.page),
      talbots:   () => new TalbotsHomePage(this.page),
      lanebryant:() => new LaneBryantHomePage(this.page),
      havenwellwithin:() => new HavenWellWithinHomePage(this.page),
      saucedemo: () => new SauceDemoHomePage(this.page),
    }, () => new BaseHomePage(this.page, this.brand.id));
  }

  searchResults(): BaseSearchResultsPage {
    return pick(this.brand.id, {
      anntaylor: () => new AnnTaylorSearchResultsPage(this.page),
      talbots:   () => new TalbotsSearchResultsPage(this.page),
      lanebryant:() => new LaneBryantSearchResultsPage(this.page),
      havenwellwithin:() => new HavenWellWithinSearchResultsPage(this.page),
      saucedemo: () => new SauceDemoSearchResultsPage(this.page),
    }, () => new BaseSearchResultsPage(this.page, this.brand.id));
  }

  plp(): BasePLPPage {
    return pick(this.brand.id, {
      anntaylor: () => new AnnTaylorPLPPage(this.page),
      talbots:   () => new TalbotsPLPPage(this.page),
      lanebryant:() => new LaneBryantPLPPage(this.page),
      havenwellwithin:() => new HavenWellWithinPLPPage(this.page),
      saucedemo: () => new SauceDemoPLPPage(this.page),
    }, () => new BasePLPPage(this.page, this.brand.id));
  }

  pdp(): BasePDPPage {
    return pick(this.brand.id, {
      anntaylor: () => new AnnTaylorPDPPage(this.page),
      talbots:   () => new TalbotsPDPPage(this.page),
      lanebryant:() => new LaneBryantPDPPage(this.page),
      havenwellwithin:() => new HavenWellWithinPDPPage(this.page),
      saucedemo: () => new SauceDemoPDPPage(this.page),
    }, () => new BasePDPPage(this.page, this.brand.id));
  }

  cart(): BaseCartPage {
    return pick(this.brand.id, {
      anntaylor: () => new AnnTaylorCartPage(this.page),
      talbots:   () => new TalbotsCartPage(this.page),
      lanebryant:() => new LaneBryantCartPage(this.page),
      havenwellwithin:() => new HavenWellWithinCartPage(this.page),
      saucedemo: () => new SauceDemoCartPage(this.page),
    }, () => new BaseCartPage(this.page, this.brand.id));
  }

  checkout(): BaseCheckoutPage {
    const pay = paymentFor(this.brand);
    return pick(this.brand.id, {
      anntaylor: () => new AnnTaylorCheckoutPage(this.page, pay),
      talbots:   () => new TalbotsCheckoutPage(this.page, pay),
      lanebryant:() => new LaneBryantCheckoutPage(this.page, pay),
      havenwellwithin:() => new HavenWellWithinCheckoutPage(this.page, pay),
    }, () => new BaseCheckoutPage(this.page, this.brand.id, pay));
  }

  orderConfirmation(): BaseOrderConfirmationPage {
    return pick(this.brand.id, {
      anntaylor: () => new AnnTaylorOrderConfirmationPage(this.page),
      talbots:   () => new TalbotsOrderConfirmationPage(this.page),
      lanebryant:() => new LaneBryantOrderConfirmationPage(this.page),
      havenwellwithin:() => new HavenWellWithinOrderConfirmationPage(this.page),
      saucedemo: () => new SauceDemoOrderConfirmationPage(this.page),
    }, () => new BaseOrderConfirmationPage(this.page, this.brand.id));
  }
}
