import { Page } from '@playwright/test';
import { HomeLocators } from '../../locators/contracts/HomeLocators';
import { getHomeLocators } from '../../locators/registry/HomeRegistry';

/**
 * Base Home page object. Holds the Shared/Override method BODIES once; resolves
 * selectors per brand through the registry. Brand seams extend this.
 */
export class BaseHomePage {
  protected readonly page: Page;
  protected readonly L: HomeLocators;

  constructor(page: Page, brandId: string) {
    this.page = page;
    this.L = getHomeLocators(brandId);
  }

  async search(term: string): Promise<void> {
    const i = this.L.searchInput(this.page);
    await i.waitFor({ state: 'visible', timeout: 15000 });
    await i.fill(term).catch(() => {});
  }

  async openCategory(name: string): Promise<void> {
    await this.L.categoryNavLink(this.page).first().click().catch(() => {});
  }
}
