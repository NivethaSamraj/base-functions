import { Page } from '@playwright/test';
import { OrderConfirmationLocators } from '../../locators/contracts/OrderConfirmationLocators';
import { getOrderConfirmationLocators } from '../../locators/registry/OrderConfirmationRegistry';

/**
 * Base OrderConfirmation page object. Holds the Shared/Override method BODIES once; resolves
 * selectors per brand through the registry. Brand seams extend this.
 */
export class BaseOrderConfirmationPage {
  protected readonly page: Page;
  protected readonly L: OrderConfirmationLocators;

  constructor(page: Page, brandId: string) {
    this.page = page;
    this.L = getOrderConfirmationLocators(brandId);
  }

  async getConfirmationText(): Promise<string> {
    const el = this.L.confirmationHeader(this.page).first();
    await el.waitFor({ state: 'visible', timeout: 30000 });
    return (await el.textContent())?.trim() ?? '';
  }

  async getOrderNumber(): Promise<string> {
    return (await this.L.orderNumber(this.page).first().textContent())?.trim() ?? '';
  }
}
