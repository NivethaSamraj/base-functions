import { Page } from '@playwright/test';
import { CartLocators } from '../../locators/contracts/CartLocators';
import { getCartLocators } from '../../locators/registry/CartRegistry';

/**
 * Base Cart page object. Holds the Shared/Override method BODIES once; resolves
 * selectors per brand through the registry. Brand seams extend this.
 */
export class BaseCartPage {
  protected readonly page: Page;
  protected readonly L: CartLocators;

  constructor(page: Page, brandId: string) {
    this.page = page;
    this.L = getCartLocators(brandId);
  }

  async getProductNames(): Promise<string[]> {
    return (await this.L.lineItemName(this.page).allTextContents()).map(s => s.trim());
  }

  async proceedToCheckout(): Promise<void> {
    await this.L.checkoutButton(this.page).first().click();
  }
}
