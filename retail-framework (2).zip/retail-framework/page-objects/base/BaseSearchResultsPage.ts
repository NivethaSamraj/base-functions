import { Page } from '@playwright/test';
import { SearchResultsLocators } from '../../locators/contracts/SearchResultsLocators';
import { getSearchResultsLocators } from '../../locators/registry/SearchResultsRegistry';

/**
 * Base SearchResults page object. Holds the Shared/Override method BODIES once; resolves
 * selectors per brand through the registry. Brand seams extend this.
 */
export class BaseSearchResultsPage {
  protected readonly page: Page;
  protected readonly L: SearchResultsLocators;

  constructor(page: Page, brandId: string) {
    this.page = page;
    this.L = getSearchResultsLocators(brandId);
  }

  async getResultCount(): Promise<number> {
    return this.L.resultCount(this.page).count();
  }

  async openFirstResult(): Promise<void> {
    await this.L.resultTile(this.page).first().click();
  }
}
