import { Page } from '@playwright/test';
import { PdpLocators } from '../../locators/contracts/PDPLocators';
import { getPDPLocators } from '../../locators/registry/PDPRegistry';

/**
 * Base PDP page object. Holds the Shared/Override method BODIES once; resolves
 * selectors per brand through the registry. Brand seams extend this.
 */
export class BasePDPPage {
  protected readonly page: Page;
  protected readonly L: PdpLocators;

  constructor(page: Page, brandId: string) {
    this.page = page;
    this.L = getPDPLocators(brandId);
  }

  async getProductName(): Promise<string> {
    return (await this.L.productName(this.page).first().textContent())?.trim() ?? '';
  }

  async selectFirstAvailableSize(): Promise<void> {
    const s = this.L.sizeOption(this.page);
    if (await s.count()) await s.first().click().catch(() => {});
  }

  async addToCart(): Promise<void> {
    await this.L.addToCart(this.page).first().click();
  }

  async goToCart(): Promise<void> {
    await this.L.goToCartLink(this.page).first().click();
  }
}
