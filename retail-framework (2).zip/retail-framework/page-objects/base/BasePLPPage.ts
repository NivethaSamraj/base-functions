import { Page } from '@playwright/test';
import { PlpLocators } from '../../locators/contracts/PLPLocators';
import { getPLPLocators } from '../../locators/registry/PLPRegistry';

/**
 * Base PLP page object. Holds the Shared/Override method BODIES once; resolves
 * selectors per brand through the registry. Brand seams extend this.
 */
export class BasePLPPage {
  protected readonly page: Page;
  protected readonly L: PlpLocators;

  constructor(page: Page, brandId: string) {
    this.page = page;
    this.L = getPLPLocators(brandId);
  }

  async openFirstProduct(): Promise<void> {
    await this.L.productTile(this.page).first().click();
  }

  async sortBy(value: string): Promise<void> {
    await this.L.sortDropdown(this.page).selectOption(value).catch(() => {});
  }
}
