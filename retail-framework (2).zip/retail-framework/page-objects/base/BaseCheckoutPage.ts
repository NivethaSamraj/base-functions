import { Page } from '@playwright/test';
import { CheckoutLocators } from '../../locators/registry/locatorTypes';
import { getLocators } from '../../locators/registry/LocatorRegistry';
import { PaymentStrategy, CardDetails } from '../payments/PaymentStrategy';

export interface ShippingAddress {
  firstName: string;
  lastName: string;
  email: string;
  address1: string;
  zipCode: string;
  city: string;
  state: string;
  phone: string;
}

/**
 * BaseCheckoutPage owns ONLY the checkout flow: identification -> shipping ->
 * payment -> place order. Discovery/PDP/cart now live in their own page objects
 * (BaseHomePage, BasePLPPage, BasePDPPage, BaseCartPage).
 *
 * Selector-only brand differences are absorbed by the registry (this.L).
 * The genuinely divergent payment step is injected as a PaymentStrategy.
 */
export class BaseCheckoutPage {
  protected readonly page: Page;
  protected readonly L: CheckoutLocators;
  private readonly payment: PaymentStrategy;

  constructor(page: Page, brandId: string, payment: PaymentStrategy) {
    this.page = page;
    this.L = getLocators(brandId);
    this.payment = payment;
  }

  // ---- Identification ----
  async checkoutAsGuest(): Promise<void> {
    await this.L.checkoutAsGuestButton(this.page).first().click().catch(() => {});
  }

  // ---- Shipping (OVERRIDE: one body, per-brand selectors) ----
  async enterShippingAddress(a: ShippingAddress): Promise<void> {
    await this.fill(this.L.inpFirstName(this.page), a.firstName);
    await this.fill(this.L.inpLastName(this.page), a.lastName);
    await this.fill(this.L.inpEmail(this.page), a.email, true);
    await this.fill(this.L.inpAddress1(this.page), a.address1, true);
    await this.fill(this.L.inpCity(this.page), a.city, true);
    await this.selectState(a.state);
    await this.fill(this.L.inpZipCode(this.page), a.zipCode);
    await this.fill(this.L.inpPhone(this.page), a.phone, true);
  }

  async continueShipping(): Promise<void> {
    const btn = this.L.btnContinueShipping(this.page);
    await btn.waitFor({ state: 'visible', timeout: 30000 });
    await btn.scrollIntoViewIfNeeded();
    await btn.click();

    const ready = this.L.paymentSectionReady(this.page);
    const err = this.L.shippingError(this.page);
    const outcome = await Promise.race([
      ready.waitFor({ state: 'visible', timeout: 30000 }).then(() => 'ok' as const),
      err.waitFor({ state: 'visible', timeout: 30000 }).then(() => 'error' as const),
    ]).catch(() => 'timeout' as const);

    if (outcome === 'error') {
      const msg = (await err.textContent().catch(() => ''))?.trim();
      throw new Error(`Shipping step rejected: "${msg}"`);
    }
    if (outcome === 'timeout') {
      throw new Error('Shipping continue clicked but payment section never appeared.');
    }
  }

  // ---- Payment (BRAND-SPECIFIC: delegated to strategy) ----
  async pay(card: CardDetails): Promise<void> {
    const res = await this.payment.pay(this.page, this.L, card);
    if (res.outcome !== 'placeorder') {
      throw new Error(`Payment failed (${res.outcome}): ${res.message ?? 'no detail'}`);
    }
  }

  // ---- Place order ----
  async placeOrder(): Promise<void> {
    await this.L.btnPlaceOrder(this.page).first().click().catch(() => {});
  }

  // ---- helpers ----
  private async fill(locator: ReturnType<CheckoutLocators['inpFirstName']>, value: string, optional = false) {
    try {
      await locator.waitFor({ state: 'visible', timeout: optional ? 4000 : 30000 });
      await locator.fill(value);
    } catch (e) {
      if (!optional) throw e;
    }
  }

  private async selectState(value: string) {
    try {
      await this.L.drpState(this.page).selectOption(value);
    } catch { /* no state dropdown on some brands */ }
  }
}
