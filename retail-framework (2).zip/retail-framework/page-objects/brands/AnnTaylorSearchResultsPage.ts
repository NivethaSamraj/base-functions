import { Page } from '@playwright/test';
import { BaseSearchResultsPage } from '../base/BaseSearchResultsPage';

/**
 * AnnTaylor SearchResults page. Inherits base flow; override a method ONLY if AnnTaylor's
 * SearchResults FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/anntaylor/searchresultsLocators.ts.
 */
export class AnnTaylorSearchResultsPage extends BaseSearchResultsPage {
  constructor(page: Page) {
    super(page, 'anntaylor');
  }
}
