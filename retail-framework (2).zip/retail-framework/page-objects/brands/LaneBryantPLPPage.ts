import { Page } from '@playwright/test';
import { BasePLPPage } from '../base/BasePLPPage';

/**
 * LaneBryant PLP page. Inherits base flow; override a method ONLY if LaneBryant's
 * PLP FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/lanebryant/plpLocators.ts.
 */
export class LaneBryantPLPPage extends BasePLPPage {
  constructor(page: Page) {
    super(page, 'lanebryant');
  }
}
