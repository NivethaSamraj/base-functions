import { Page } from '@playwright/test';
import { BaseCartPage } from '../base/BaseCartPage';

/**
 * SauceDemo Cart page. Inherits base flow; override a method ONLY if SauceDemo's
 * Cart FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/saucedemo/cartLocators.ts.
 */
export class SauceDemoCartPage extends BaseCartPage {
  constructor(page: Page) {
    super(page, 'saucedemo');
  }
}
