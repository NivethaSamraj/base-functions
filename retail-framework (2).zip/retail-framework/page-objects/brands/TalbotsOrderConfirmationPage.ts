import { Page } from '@playwright/test';
import { BaseOrderConfirmationPage } from '../base/BaseOrderConfirmationPage';

/**
 * Talbots OrderConfirmation page. Inherits base flow; override a method ONLY if Talbots's
 * OrderConfirmation FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/talbots/orderconfirmationLocators.ts.
 */
export class TalbotsOrderConfirmationPage extends BaseOrderConfirmationPage {
  constructor(page: Page) {
    super(page, 'talbots');
  }
}
