import { Page } from '@playwright/test';
import { BaseHomePage } from '../base/BaseHomePage';

/**
 * AnnTaylor Home page. Inherits base flow; override a method ONLY if AnnTaylor's
 * Home FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/anntaylor/homeLocators.ts.
 */
export class AnnTaylorHomePage extends BaseHomePage {
  constructor(page: Page) {
    super(page, 'anntaylor');
  }
}
