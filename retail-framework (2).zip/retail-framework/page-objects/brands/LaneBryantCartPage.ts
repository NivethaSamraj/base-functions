import { Page } from '@playwright/test';
import { BaseCartPage } from '../base/BaseCartPage';

/**
 * LaneBryant Cart page. Inherits base flow; override a method ONLY if LaneBryant's
 * Cart FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/lanebryant/cartLocators.ts.
 */
export class LaneBryantCartPage extends BaseCartPage {
  constructor(page: Page) {
    super(page, 'lanebryant');
  }
}
