import { Page } from '@playwright/test';
import { BasePLPPage } from '../base/BasePLPPage';

/**
 * AnnTaylor PLP page. Inherits base flow; override a method ONLY if AnnTaylor's
 * PLP FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/anntaylor/plpLocators.ts.
 */
export class AnnTaylorPLPPage extends BasePLPPage {
  constructor(page: Page) {
    super(page, 'anntaylor');
  }
}
