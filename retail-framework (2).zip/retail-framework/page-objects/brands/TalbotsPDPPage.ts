import { Page } from '@playwright/test';
import { BasePDPPage } from '../base/BasePDPPage';

/**
 * Talbots PDP page. Inherits base flow; override a method ONLY if Talbots's
 * PDP FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/talbots/pdpLocators.ts.
 */
export class TalbotsPDPPage extends BasePDPPage {
  constructor(page: Page) {
    super(page, 'talbots');
  }
}
