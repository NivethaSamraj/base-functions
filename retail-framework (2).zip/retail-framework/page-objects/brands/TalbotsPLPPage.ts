import { Page } from '@playwright/test';
import { BasePLPPage } from '../base/BasePLPPage';

/**
 * Talbots PLP page. Inherits base flow; override a method ONLY if Talbots's
 * PLP FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/talbots/plpLocators.ts.
 */
export class TalbotsPLPPage extends BasePLPPage {
  constructor(page: Page) {
    super(page, 'talbots');
  }
}
