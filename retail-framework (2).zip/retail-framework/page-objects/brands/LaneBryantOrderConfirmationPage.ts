import { Page } from '@playwright/test';
import { BaseOrderConfirmationPage } from '../base/BaseOrderConfirmationPage';

/**
 * LaneBryant OrderConfirmation page. Inherits base flow; override a method ONLY if LaneBryant's
 * OrderConfirmation FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/lanebryant/orderconfirmationLocators.ts.
 */
export class LaneBryantOrderConfirmationPage extends BaseOrderConfirmationPage {
  constructor(page: Page) {
    super(page, 'lanebryant');
  }
}
