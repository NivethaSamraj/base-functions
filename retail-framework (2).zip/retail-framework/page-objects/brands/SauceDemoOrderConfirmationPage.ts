import { Page } from '@playwright/test';
import { BaseOrderConfirmationPage } from '../base/BaseOrderConfirmationPage';

/**
 * SauceDemo OrderConfirmation page. Inherits base flow; override a method ONLY if SauceDemo's
 * OrderConfirmation FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/saucedemo/orderconfirmationLocators.ts.
 */
export class SauceDemoOrderConfirmationPage extends BaseOrderConfirmationPage {
  constructor(page: Page) {
    super(page, 'saucedemo');
  }
}
