import { Page } from '@playwright/test';
import { BaseHomePage } from '../base/BaseHomePage';

/**
 * Talbots Home page. Inherits base flow; override a method ONLY if Talbots's
 * Home FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/talbots/homeLocators.ts.
 */
export class TalbotsHomePage extends BaseHomePage {
  constructor(page: Page) {
    super(page, 'talbots');
  }
}
