import { Page } from '@playwright/test';
import { BaseCartPage } from '../base/BaseCartPage';

/**
 * HavenWellWithin Cart page. Inherits base flow; override a method ONLY if HavenWellWithin's
 * Cart FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/havenwellwithin/cartLocators.ts.
 */
export class HavenWellWithinCartPage extends BaseCartPage {
  constructor(page: Page) {
    super(page, 'havenwellwithin');
  }
}
