import { Page } from '@playwright/test';
import { BasePDPPage } from '../base/BasePDPPage';

/**
 * SauceDemo PDP page. Inherits base flow; override a method ONLY if SauceDemo's
 * PDP FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/saucedemo/pdpLocators.ts.
 */
export class SauceDemoPDPPage extends BasePDPPage {
  constructor(page: Page) {
    super(page, 'saucedemo');
  }
}
