import { Page } from '@playwright/test';
import { BaseCartPage } from '../base/BaseCartPage';

/**
 * Talbots Cart page. Inherits base flow; override a method ONLY if Talbots's
 * Cart FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/talbots/cartLocators.ts.
 */
export class TalbotsCartPage extends BaseCartPage {
  constructor(page: Page) {
    super(page, 'talbots');
  }
}
