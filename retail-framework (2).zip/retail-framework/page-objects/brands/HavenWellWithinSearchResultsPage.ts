import { Page } from '@playwright/test';
import { BaseSearchResultsPage } from '../base/BaseSearchResultsPage';

/**
 * HavenWellWithin SearchResults page. Inherits base flow; override a method ONLY if HavenWellWithin's
 * SearchResults FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/havenwellwithin/searchresultsLocators.ts.
 */
export class HavenWellWithinSearchResultsPage extends BaseSearchResultsPage {
  constructor(page: Page) {
    super(page, 'havenwellwithin');
  }
}
