import { Page } from '@playwright/test';
import { BaseSearchResultsPage } from '../base/BaseSearchResultsPage';

/**
 * Talbots SearchResults page. Inherits base flow; override a method ONLY if Talbots's
 * SearchResults FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/talbots/searchresultsLocators.ts.
 */
export class TalbotsSearchResultsPage extends BaseSearchResultsPage {
  constructor(page: Page) {
    super(page, 'talbots');
  }
}
