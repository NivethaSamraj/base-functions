import { Page } from '@playwright/test';
import { BasePDPPage } from '../base/BasePDPPage';

/**
 * AnnTaylor PDP page. Inherits base flow; override a method ONLY if AnnTaylor's
 * PDP FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/anntaylor/pdpLocators.ts.
 */
export class AnnTaylorPDPPage extends BasePDPPage {
  constructor(page: Page) {
    super(page, 'anntaylor');
  }
}
