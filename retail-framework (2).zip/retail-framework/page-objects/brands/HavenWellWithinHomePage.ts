import { Page } from '@playwright/test';
import { BaseHomePage } from '../base/BaseHomePage';

/**
 * HavenWellWithin Home page. Inherits base flow; override a method ONLY if HavenWellWithin's
 * Home FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/havenwellwithin/homeLocators.ts.
 */
export class HavenWellWithinHomePage extends BaseHomePage {
  constructor(page: Page) {
    super(page, 'havenwellwithin');
  }
}
