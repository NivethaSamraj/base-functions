import { Page } from '@playwright/test';
import { BaseCheckoutPage } from '../base/BaseCheckoutPage';
import { PaymentStrategy } from '../payments/PaymentStrategy';

/**
 * HavenWellWithin checkout page object  (brand id: 'havenwellwithin', platform: SFCC).
 *
 * Inherits every Shared/Override method body from BaseCheckoutPage. HavenWellWithin's
 * selector differences live in locators/brands/havenwellwithin/, and its payment is the
 * shared SFCC-Aurus strategy. Override a method below ONLY if HavenWellWithin's checkout
 * FLOW diverges (an extra step/modal) — not for selectors or payment.
 */
export class HavenWellWithinCheckoutPage extends BaseCheckoutPage {
  constructor(page: Page, payment: PaymentStrategy) {
    super(page, 'havenwellwithin', payment);
  }

  // No flow divergence known for HavenWellWithin yet — inherits base.
  // Example (enable only if real):
  // async continueShipping(): Promise<void> {
  //   await super.continueShipping();
  //   // HavenWellWithin-only extra step here
  // }
}
