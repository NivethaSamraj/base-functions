import { Page } from '@playwright/test';
import { BasePDPPage } from '../base/BasePDPPage';

/**
 * LaneBryant PDP page. Inherits base flow; override a method ONLY if LaneBryant's
 * PDP FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/lanebryant/pdpLocators.ts.
 */
export class LaneBryantPDPPage extends BasePDPPage {
  constructor(page: Page) {
    super(page, 'lanebryant');
  }
}
