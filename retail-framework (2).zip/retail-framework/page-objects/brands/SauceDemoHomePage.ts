import { Page } from '@playwright/test';
import { BaseHomePage } from '../base/BaseHomePage';

/**
 * SauceDemo Home page. Inherits base flow; override a method ONLY if SauceDemo's
 * Home FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/saucedemo/homeLocators.ts.
 */
export class SauceDemoHomePage extends BaseHomePage {
  constructor(page: Page) {
    super(page, 'saucedemo');
  }
}
