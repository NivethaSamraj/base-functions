import { Page } from '@playwright/test';
import { BaseHomePage } from '../base/BaseHomePage';

/**
 * LaneBryant Home page. Inherits base flow; override a method ONLY if LaneBryant's
 * Home FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/lanebryant/homeLocators.ts.
 */
export class LaneBryantHomePage extends BaseHomePage {
  constructor(page: Page) {
    super(page, 'lanebryant');
  }
}
