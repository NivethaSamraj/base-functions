import { Page } from '@playwright/test';
import { BaseSearchResultsPage } from '../base/BaseSearchResultsPage';

/**
 * LaneBryant SearchResults page. Inherits base flow; override a method ONLY if LaneBryant's
 * SearchResults FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/lanebryant/searchresultsLocators.ts.
 */
export class LaneBryantSearchResultsPage extends BaseSearchResultsPage {
  constructor(page: Page) {
    super(page, 'lanebryant');
  }
}
