import { Page } from '@playwright/test';
import { BaseOrderConfirmationPage } from '../base/BaseOrderConfirmationPage';

/**
 * AnnTaylor OrderConfirmation page. Inherits base flow; override a method ONLY if AnnTaylor's
 * OrderConfirmation FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/anntaylor/orderconfirmationLocators.ts.
 */
export class AnnTaylorOrderConfirmationPage extends BaseOrderConfirmationPage {
  constructor(page: Page) {
    super(page, 'anntaylor');
  }
}
