import { Page } from '@playwright/test';
import { BasePLPPage } from '../base/BasePLPPage';

/**
 * SauceDemo PLP page. Inherits base flow; override a method ONLY if SauceDemo's
 * PLP FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/saucedemo/plpLocators.ts.
 */
export class SauceDemoPLPPage extends BasePLPPage {
  constructor(page: Page) {
    super(page, 'saucedemo');
  }
}
