import { Page } from '@playwright/test';
import { BasePDPPage } from '../base/BasePDPPage';

/**
 * HavenWellWithin PDP page. Inherits base flow; override a method ONLY if HavenWellWithin's
 * PDP FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/havenwellwithin/pdpLocators.ts.
 */
export class HavenWellWithinPDPPage extends BasePDPPage {
  constructor(page: Page) {
    super(page, 'havenwellwithin');
  }
}
