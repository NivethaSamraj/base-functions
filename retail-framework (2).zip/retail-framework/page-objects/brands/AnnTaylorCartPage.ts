import { Page } from '@playwright/test';
import { BaseCartPage } from '../base/BaseCartPage';

/**
 * AnnTaylor Cart page. Inherits base flow; override a method ONLY if AnnTaylor's
 * Cart FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/anntaylor/cartLocators.ts.
 */
export class AnnTaylorCartPage extends BaseCartPage {
  constructor(page: Page) {
    super(page, 'anntaylor');
  }
}
