import { Page } from '@playwright/test';
import { BasePLPPage } from '../base/BasePLPPage';

/**
 * HavenWellWithin PLP page. Inherits base flow; override a method ONLY if HavenWellWithin's
 * PLP FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/havenwellwithin/plpLocators.ts.
 */
export class HavenWellWithinPLPPage extends BasePLPPage {
  constructor(page: Page) {
    super(page, 'havenwellwithin');
  }
}
