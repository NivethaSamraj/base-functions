import { Page } from '@playwright/test';
import { BaseSearchResultsPage } from '../base/BaseSearchResultsPage';

/**
 * SauceDemo SearchResults page. Inherits base flow; override a method ONLY if SauceDemo's
 * SearchResults FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/saucedemo/searchresultsLocators.ts.
 */
export class SauceDemoSearchResultsPage extends BaseSearchResultsPage {
  constructor(page: Page) {
    super(page, 'saucedemo');
  }
}
