import { Page } from '@playwright/test';
import { BaseOrderConfirmationPage } from '../base/BaseOrderConfirmationPage';

/**
 * HavenWellWithin OrderConfirmation page. Inherits base flow; override a method ONLY if HavenWellWithin's
 * OrderConfirmation FLOW diverges (extra step/modal). Selectors live in
 * locators/brands/havenwellwithin/orderconfirmationLocators.ts.
 */
export class HavenWellWithinOrderConfirmationPage extends BaseOrderConfirmationPage {
  constructor(page: Page) {
    super(page, 'havenwellwithin');
  }
}
