# Framework structure — full journey

Every page in the funnel follows the SAME three-layer pattern as checkout.

## Layers (per page)

| Layer | Path | Purpose |
|-------|------|---------|
| Contract | `locators/contracts/<Page>Locators.ts` | Typed key set. Typos -> compile error. |
| Base selectors | `locators/base/<page>BaseLocators.ts` | Default selector for every key. |
| Brand selectors | `locators/brands/<brand>/<page>Locators.ts` | ONLY keys that differ (Override). |
| Registry | `locators/registry/<Page>Registry.ts` | Spread-merge base + brand. |
| Base page object | `page-objects/base/Base<Page>Page.ts` | Method bodies, written once. |
| Brand page object | `page-objects/brands/<Brand><Page>Page.ts` | Named seam; override only flow divergence. |

## Pages covered
Home, SearchResults, PLP, PDP, Cart, Checkout, OrderConfirmation

## Orchestration
- `page-objects/PageFactory.ts` — returns the right brand page object per page.
- `scenarios/CheckoutScenarios.ts` — brand-agnostic journeys, written once.

## Find brand X's code
- Selectors: `locators/brands/<x>/`
- Flow overrides: `page-objects/brands/<X>*Page.ts`
- Payment: `page-objects/payments/` (shared by platform)

Most brand page objects are intentionally empty seams (inherit base) — their real
differences are selectors. A seam gains a method only when that brand's page FLOW
diverges (extra step/modal).
