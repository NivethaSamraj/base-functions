import { test, expect } from '../fixtures/testFixture';
import { CheckoutScenarios } from '../scenarios/CheckoutScenarios';
import { GUEST_ADDRESS, TEST_CARD, DEMO_USER } from '../config/testData';

/**
 * Reference E2E across the FULL journey on SauceDemo. Exercises Home/PLP/PDP/
 * Cart/Checkout/OrderConfirmation page objects via the scenario layer.
 * Run: npm run test:saucedemo
 */
test.describe('Demo brand — full journey (green)', () => {
  test('TC001 - browse, add to cart, place order', async ({ page, brand }) => {
    test.skip(brand.platform !== 'demo', 'Demo-only spec.');

    await page.goto('/');
    await page.locator('#user-name').fill(DEMO_USER.username);
    await page.locator('#password').fill(DEMO_USER.password);
    await page.locator('#login-button').click();
    await expect(page.locator('.inventory_list')).toBeVisible();

    const scenarios = new CheckoutScenarios(page, brand);

    const productName = await scenarios.browseAndAddToCart();
    expect(productName.length).toBeGreaterThan(0);

    const confirmation = await scenarios.guestCheckout(GUEST_ADDRESS, TEST_CARD);
    expect(confirmation.toLowerCase()).toContain('thank you');
  });
});
